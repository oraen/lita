(function() {
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	//#endregion
	//#region xhs/runtime.js
	if (!Object.fromEntries) Object.fromEntries = function(entries) {
		const result = {};
		for (const [key, value] of entries) Object.defineProperty(result, key, {
			value,
			enumerable: true,
			configurable: true,
			writable: true
		});
		return result;
	};
	if (!Array.prototype.at) Object.defineProperty(Array.prototype, "at", {
		configurable: true,
		writable: true,
		value(index) {
			const offset = Math.trunc(Number(index)) || 0;
			return this[offset < 0 ? this.length + offset : offset];
		}
	});
	if (!Element.prototype.replaceChildren) Element.prototype.replaceChildren = function(...children) {
		while (this.firstChild) this.removeChild(this.firstChild);
		this.append(...children);
	};
	var probe = document.createElement("div");
	probe.style.cssText = "position:absolute;visibility:hidden;display:flex;flex-direction:column;row-gap:1px";
	probe.append(document.createElement("div"), document.createElement("div"));
	document.body.append(probe);
	document.documentElement.classList.toggle("no-flex-gap", probe.scrollHeight !== 1);
	probe.remove();
	//#endregion
	//#region professional-test.js
	var ANCHOR_FREQUENCIES = [
		1e4,
		15e3,
		2e4,
		5e3,
		7500,
		12500,
		17500,
		2500,
		1e3,
		500,
		100,
		20
	];
	function createProfessionalTest() {
		return {
			phase: "low",
			anchorIndex: 0,
			lower: 19,
			upper: null,
			frequency: ANCHOR_FREQUENCIES[0],
			trials: 0,
			streak: 0,
			signalInStreak: false,
			confirmed: 0,
			minimum: null,
			maximum: null
		};
	}
	function chooseProfessionalSignal(test, random = Math.random) {
		if (test.streak === 2 && !test.signalInStreak) return true;
		return random() < .5;
	}
	function answerProfessionalTrial(test, signal, answer) {
		if (answer !== "yes" && answer !== "no" && answer !== "certain") throw new TypeError("Answer must be yes, no or certain");
		const correct = (answer === "yes" || answer === "certain") === signal;
		test.trials += 1;
		if (correct) {
			test.streak += 1;
			if (signal) test.signalInStreak = true;
		}
		if (!correct) advanceFrequency(test, false);
		else if (answer === "certain" && correct || test.streak >= 3 && test.signalInStreak) advanceFrequency(test, true);
		return {
			correct,
			done: test.phase === "done"
		};
	}
	function advanceFrequency(test, audible) {
		if (test.phase === "low" && test.upper === null) {
			if (audible) {
				test.upper = test.frequency;
				if (test.upper === 20) startHigh(test);
				else test.frequency = test.upper === 1e4 ? 5e3 : Math.floor((test.lower + test.upper) / 2);
			} else {
				test.anchorIndex += 1;
				if (test.anchorIndex === ANCHOR_FREQUENCIES.length) test.phase = "done";
				else test.frequency = ANCHOR_FREQUENCIES[test.anchorIndex];
			}
		} else if (test.phase === "low") {
			if (audible) test.upper = test.frequency;
			else test.lower = test.frequency;
			if (test.upper - test.lower <= 1) startHigh(test);
			else test.frequency = Math.floor((test.lower + test.upper) / 2);
		} else {
			if (audible) test.lower = test.frequency;
			else test.upper = test.frequency;
			if (test.upper - test.lower <= 1) {
				test.maximum = test.lower;
				test.phase = "done";
			} else test.frequency = Math.floor((test.lower + test.upper) / 2);
		}
		test.confirmed += 1;
		test.trials = 0;
		test.streak = 0;
		test.signalInStreak = false;
	}
	function startHigh(test) {
		test.minimum = test.upper;
		test.phase = "high";
		test.lower = test.minimum;
		test.upper = 20001;
		test.frequency = test.minimum < 15e3 ? 15e3 : Math.floor((test.lower + test.upper) / 2);
	}
	//#endregion
	//#region hearing-title.js
	var HEARING_TITLES = [
		[6e3, "聋子"],
		[8e3, "老年人"],
		[12e3, "中老年人"],
		[16e3, "老当益壮"],
		[17e3, "正值壮年"],
		[18e3, "偷听者"],
		[19e3, "耳报神"],
		[2e4, "大听四方"],
		[22e3, "通灵耳"]
	];
	function getHearingTitle(maximum) {
		var _HEARING_TITLES$find$, _HEARING_TITLES$find;
		if (!Number.isFinite(maximum)) return "未获得";
		return (_HEARING_TITLES$find$ = (_HEARING_TITLES$find = HEARING_TITLES.find(([limit]) => maximum < limit)) === null || _HEARING_TITLES$find === void 0 ? void 0 : _HEARING_TITLES$find[1]) !== null && _HEARING_TITLES$find$ !== void 0 ? _HEARING_TITLES$find$ : "天下无耳";
	}
	function getHearingLevelRank(maximum) {
		if (!Number.isFinite(maximum)) return null;
		const index = HEARING_TITLES.findIndex(([limit]) => maximum < limit);
		const categoryIndex = index === -1 ? HEARING_TITLES.length : index;
		return HEARING_TITLES.length - categoryIndex;
	}
	//#endregion
	//#region voice-title.js
	var VOICE_TITLES = [
		[600, "发音障碍"],
		[800, "五音不全"],
		[1e3, "天癞之音"],
		[1200, "全是感情"],
		[1300, "小吴强"],
		[1400, "战平吴强"],
		[1500, "怪叫之源"],
		[1600, "会狮吼功"],
		[1800, "无需技巧"],
		[2e3, "会超声波"]
	];
	function getVoiceTitle(maximum) {
		var _VOICE_TITLES$find$, _VOICE_TITLES$find;
		if (!Number.isFinite(maximum)) return "未获得";
		return (_VOICE_TITLES$find$ = (_VOICE_TITLES$find = VOICE_TITLES.find(([limit]) => maximum < limit)) === null || _VOICE_TITLES$find === void 0 ? void 0 : _VOICE_TITLES$find[1]) !== null && _VOICE_TITLES$find$ !== void 0 ? _VOICE_TITLES$find$ : "嘴强王者";
	}
	function getVoiceLevelRank(maximum) {
		if (!Number.isFinite(maximum)) return null;
		const index = VOICE_TITLES.findIndex(([limit]) => maximum < limit);
		const categoryIndex = index === -1 ? VOICE_TITLES.length : index;
		return VOICE_TITLES.length - categoryIndex;
	}
	//#endregion
	//#region level-badge.js
	var LEVEL_COLOR_CLASSES = [
		"level-badge--dark-red",
		"level-badge--gold",
		"level-badge--purple",
		"level-badge--blue",
		"level-badge--yellow",
		"level-badge--green",
		"level-badge--gray"
	];
	function getLevelBadgeClass(rankFromBest) {
		if (!Number.isInteger(rankFromBest) || rankFromBest < 0) return LEVEL_COLOR_CLASSES.at(-1);
		return LEVEL_COLOR_CLASSES[Math.min(rankFromBest, LEVEL_COLOR_CLASSES.length - 1)];
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.150.0/helpers/esm/typeof.js
	var import_fft = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		function FFT(size) {
			this.size = size | 0;
			if (this.size <= 1 || (this.size & this.size - 1) !== 0) throw new Error("FFT size must be a power of two and bigger than 1");
			this._csize = size << 1;
			var table = new Array(this.size * 2);
			for (var i = 0; i < table.length; i += 2) {
				const angle = Math.PI * i / this.size;
				table[i] = Math.cos(angle);
				table[i + 1] = -Math.sin(angle);
			}
			this.table = table;
			var power = 0;
			for (var t = 1; this.size > t; t <<= 1) power++;
			this._width = power % 2 === 0 ? power - 1 : power;
			this._bitrev = new Array(1 << this._width);
			for (var j = 0; j < this._bitrev.length; j++) {
				this._bitrev[j] = 0;
				for (var shift = 0; shift < this._width; shift += 2) {
					var revShift = this._width - shift - 2;
					this._bitrev[j] |= (j >>> shift & 3) << revShift;
				}
			}
			this._out = null;
			this._data = null;
			this._inv = 0;
		}
		module.exports = FFT;
		FFT.prototype.fromComplexArray = function fromComplexArray(complex, storage) {
			var res = storage || new Array(complex.length >>> 1);
			for (var i = 0; i < complex.length; i += 2) res[i >>> 1] = complex[i];
			return res;
		};
		FFT.prototype.createComplexArray = function createComplexArray() {
			const res = new Array(this._csize);
			for (var i = 0; i < res.length; i++) res[i] = 0;
			return res;
		};
		FFT.prototype.toComplexArray = function toComplexArray(input, storage) {
			var res = storage || this.createComplexArray();
			for (var i = 0; i < res.length; i += 2) {
				res[i] = input[i >>> 1];
				res[i + 1] = 0;
			}
			return res;
		};
		FFT.prototype.completeSpectrum = function completeSpectrum(spectrum) {
			var size = this._csize;
			var half = size >>> 1;
			for (var i = 2; i < half; i += 2) {
				spectrum[size - i] = spectrum[i];
				spectrum[size - i + 1] = -spectrum[i + 1];
			}
		};
		FFT.prototype.transform = function transform(out, data) {
			if (out === data) throw new Error("Input and output buffers must be different");
			this._out = out;
			this._data = data;
			this._inv = 0;
			this._transform4();
			this._out = null;
			this._data = null;
		};
		FFT.prototype.realTransform = function realTransform(out, data) {
			if (out === data) throw new Error("Input and output buffers must be different");
			this._out = out;
			this._data = data;
			this._inv = 0;
			this._realTransform4();
			this._out = null;
			this._data = null;
		};
		FFT.prototype.inverseTransform = function inverseTransform(out, data) {
			if (out === data) throw new Error("Input and output buffers must be different");
			this._out = out;
			this._data = data;
			this._inv = 1;
			this._transform4();
			for (var i = 0; i < out.length; i++) out[i] /= this.size;
			this._out = null;
			this._data = null;
		};
		FFT.prototype._transform4 = function _transform4() {
			var out = this._out;
			var size = this._csize;
			var step = 1 << this._width;
			var len = size / step << 1;
			var outOff;
			var t;
			var bitrev = this._bitrev;
			if (len === 4) for (outOff = 0, t = 0; outOff < size; outOff += len, t++) {
				const off = bitrev[t];
				this._singleTransform2(outOff, off, step);
			}
			else for (outOff = 0, t = 0; outOff < size; outOff += len, t++) {
				const off = bitrev[t];
				this._singleTransform4(outOff, off, step);
			}
			var inv = this._inv ? -1 : 1;
			var table = this.table;
			for (step >>= 2; step >= 2; step >>= 2) {
				len = size / step << 1;
				var quarterLen = len >>> 2;
				for (outOff = 0; outOff < size; outOff += len) {
					var limit = outOff + quarterLen;
					for (var i = outOff, k = 0; i < limit; i += 2, k += step) {
						const A = i;
						const B = A + quarterLen;
						const C = B + quarterLen;
						const D = C + quarterLen;
						const Ar = out[A];
						const Ai = out[A + 1];
						const Br = out[B];
						const Bi = out[B + 1];
						const Cr = out[C];
						const Ci = out[C + 1];
						const Dr = out[D];
						const Di = out[D + 1];
						const MAr = Ar;
						const MAi = Ai;
						const tableBr = table[k];
						const tableBi = inv * table[k + 1];
						const MBr = Br * tableBr - Bi * tableBi;
						const MBi = Br * tableBi + Bi * tableBr;
						const tableCr = table[2 * k];
						const tableCi = inv * table[2 * k + 1];
						const MCr = Cr * tableCr - Ci * tableCi;
						const MCi = Cr * tableCi + Ci * tableCr;
						const tableDr = table[3 * k];
						const tableDi = inv * table[3 * k + 1];
						const MDr = Dr * tableDr - Di * tableDi;
						const MDi = Dr * tableDi + Di * tableDr;
						const T0r = MAr + MCr;
						const T0i = MAi + MCi;
						const T1r = MAr - MCr;
						const T1i = MAi - MCi;
						const T2r = MBr + MDr;
						const T2i = MBi + MDi;
						const T3r = inv * (MBr - MDr);
						const T3i = inv * (MBi - MDi);
						const FAr = T0r + T2r;
						const FAi = T0i + T2i;
						const FCr = T0r - T2r;
						const FCi = T0i - T2i;
						const FBr = T1r + T3i;
						const FBi = T1i - T3r;
						const FDr = T1r - T3i;
						const FDi = T1i + T3r;
						out[A] = FAr;
						out[A + 1] = FAi;
						out[B] = FBr;
						out[B + 1] = FBi;
						out[C] = FCr;
						out[C + 1] = FCi;
						out[D] = FDr;
						out[D + 1] = FDi;
					}
				}
			}
		};
		FFT.prototype._singleTransform2 = function _singleTransform2(outOff, off, step) {
			const out = this._out;
			const data = this._data;
			const evenR = data[off];
			const evenI = data[off + 1];
			const oddR = data[off + step];
			const oddI = data[off + step + 1];
			const leftR = evenR + oddR;
			const leftI = evenI + oddI;
			const rightR = evenR - oddR;
			const rightI = evenI - oddI;
			out[outOff] = leftR;
			out[outOff + 1] = leftI;
			out[outOff + 2] = rightR;
			out[outOff + 3] = rightI;
		};
		FFT.prototype._singleTransform4 = function _singleTransform4(outOff, off, step) {
			const out = this._out;
			const data = this._data;
			const inv = this._inv ? -1 : 1;
			const step2 = step * 2;
			const step3 = step * 3;
			const Ar = data[off];
			const Ai = data[off + 1];
			const Br = data[off + step];
			const Bi = data[off + step + 1];
			const Cr = data[off + step2];
			const Ci = data[off + step2 + 1];
			const Dr = data[off + step3];
			const Di = data[off + step3 + 1];
			const T0r = Ar + Cr;
			const T0i = Ai + Ci;
			const T1r = Ar - Cr;
			const T1i = Ai - Ci;
			const T2r = Br + Dr;
			const T2i = Bi + Di;
			const T3r = inv * (Br - Dr);
			const T3i = inv * (Bi - Di);
			const FAr = T0r + T2r;
			const FAi = T0i + T2i;
			const FBr = T1r + T3i;
			const FBi = T1i - T3r;
			const FCr = T0r - T2r;
			const FCi = T0i - T2i;
			const FDr = T1r - T3i;
			const FDi = T1i + T3r;
			out[outOff] = FAr;
			out[outOff + 1] = FAi;
			out[outOff + 2] = FBr;
			out[outOff + 3] = FBi;
			out[outOff + 4] = FCr;
			out[outOff + 5] = FCi;
			out[outOff + 6] = FDr;
			out[outOff + 7] = FDi;
		};
		FFT.prototype._realTransform4 = function _realTransform4() {
			var out = this._out;
			var size = this._csize;
			var step = 1 << this._width;
			var len = size / step << 1;
			var outOff;
			var t;
			var bitrev = this._bitrev;
			if (len === 4) for (outOff = 0, t = 0; outOff < size; outOff += len, t++) {
				const off = bitrev[t];
				this._singleRealTransform2(outOff, off >>> 1, step >>> 1);
			}
			else for (outOff = 0, t = 0; outOff < size; outOff += len, t++) {
				const off = bitrev[t];
				this._singleRealTransform4(outOff, off >>> 1, step >>> 1);
			}
			var inv = this._inv ? -1 : 1;
			var table = this.table;
			for (step >>= 2; step >= 2; step >>= 2) {
				len = size / step << 1;
				var halfLen = len >>> 1;
				var quarterLen = halfLen >>> 1;
				var hquarterLen = quarterLen >>> 1;
				for (outOff = 0; outOff < size; outOff += len) for (var i = 0, k = 0; i <= hquarterLen; i += 2, k += step) {
					var A = outOff + i;
					var B = A + quarterLen;
					var C = B + quarterLen;
					var D = C + quarterLen;
					var Ar = out[A];
					var Ai = out[A + 1];
					var Br = out[B];
					var Bi = out[B + 1];
					var Cr = out[C];
					var Ci = out[C + 1];
					var Dr = out[D];
					var Di = out[D + 1];
					var MAr = Ar;
					var MAi = Ai;
					var tableBr = table[k];
					var tableBi = inv * table[k + 1];
					var MBr = Br * tableBr - Bi * tableBi;
					var MBi = Br * tableBi + Bi * tableBr;
					var tableCr = table[2 * k];
					var tableCi = inv * table[2 * k + 1];
					var MCr = Cr * tableCr - Ci * tableCi;
					var MCi = Cr * tableCi + Ci * tableCr;
					var tableDr = table[3 * k];
					var tableDi = inv * table[3 * k + 1];
					var MDr = Dr * tableDr - Di * tableDi;
					var MDi = Dr * tableDi + Di * tableDr;
					var T0r = MAr + MCr;
					var T0i = MAi + MCi;
					var T1r = MAr - MCr;
					var T1i = MAi - MCi;
					var T2r = MBr + MDr;
					var T2i = MBi + MDi;
					var T3r = inv * (MBr - MDr);
					var T3i = inv * (MBi - MDi);
					var FAr = T0r + T2r;
					var FAi = T0i + T2i;
					var FBr = T1r + T3i;
					var FBi = T1i - T3r;
					out[A] = FAr;
					out[A + 1] = FAi;
					out[B] = FBr;
					out[B + 1] = FBi;
					if (i === 0) {
						var FCr = T0r - T2r;
						var FCi = T0i - T2i;
						out[C] = FCr;
						out[C + 1] = FCi;
						continue;
					}
					if (i === hquarterLen) continue;
					var ST0r = T1r;
					var ST0i = -T1i;
					var ST1r = T0r;
					var ST1i = -T0i;
					var ST2r = -inv * T3i;
					var ST2i = -inv * T3r;
					var ST3r = -inv * T2i;
					var ST3i = -inv * T2r;
					var SFAr = ST0r + ST2r;
					var SFAi = ST0i + ST2i;
					var SFBr = ST1r + ST3i;
					var SFBi = ST1i - ST3r;
					var SA = outOff + quarterLen - i;
					var SB = outOff + halfLen - i;
					out[SA] = SFAr;
					out[SA + 1] = SFAi;
					out[SB] = SFBr;
					out[SB + 1] = SFBi;
				}
			}
		};
		FFT.prototype._singleRealTransform2 = function _singleRealTransform2(outOff, off, step) {
			const out = this._out;
			const data = this._data;
			const evenR = data[off];
			const oddR = data[off + step];
			const leftR = evenR + oddR;
			const rightR = evenR - oddR;
			out[outOff] = leftR;
			out[outOff + 1] = 0;
			out[outOff + 2] = rightR;
			out[outOff + 3] = 0;
		};
		FFT.prototype._singleRealTransform4 = function _singleRealTransform4(outOff, off, step) {
			const out = this._out;
			const data = this._data;
			const inv = this._inv ? -1 : 1;
			const step2 = step * 2;
			const step3 = step * 3;
			const Ar = data[off];
			const Br = data[off + step];
			const Cr = data[off + step2];
			const Dr = data[off + step3];
			const T0r = Ar + Cr;
			const T1r = Ar - Cr;
			const T2r = Br + Dr;
			const T3r = inv * (Br - Dr);
			const FAr = T0r + T2r;
			const FBr = T1r;
			const FBi = -T3r;
			const FCr = T0r - T2r;
			const FDr = T1r;
			const FDi = T3r;
			out[outOff] = FAr;
			out[outOff + 1] = 0;
			out[outOff + 2] = FBr;
			out[outOff + 3] = FBi;
			out[outOff + 4] = FCr;
			out[outOff + 5] = 0;
			out[outOff + 6] = FDr;
			out[outOff + 7] = FDi;
		};
	})))(), 1);
	function _typeof(o) {
		"@babel/helpers - typeof";
		return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, _typeof(o);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.150.0/helpers/esm/toPrimitive.js
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.150.0/helpers/esm/toPropertyKey.js
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.150.0/helpers/esm/defineProperty.js
	function _defineProperty(e, r, t) {
		return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : e[r] = t, e;
	}
	//#endregion
	//#region node_modules/pitchy/index.js
	/**
	* @typedef {Float32Array | Float64Array | number[]} Buffer One of the supported
	* buffer types. Other numeric array types may not work correctly.
	*/
	/**
	* A class that can perform autocorrelation on input arrays of a given size.
	*
	* The class holds internal buffers so that no additional allocations are
	* necessary while performing the operation.
	*
	* @template {Buffer} T the buffer type to use. While inputs to the
	* autocorrelation process can be any array-like type, the output buffer
	* (whether provided explicitly or using a fresh buffer) is always of this type.
	*/
	var Autocorrelator = class Autocorrelator {
		/**
		* A helper method to create an {@link Autocorrelator} using
		* {@link Float32Array} buffers.
		*
		* @param inputLength {number} the input array length to support
		* @returns {Autocorrelator<Float32Array>}
		*/
		static forFloat32Array(inputLength) {
			return new Autocorrelator(inputLength, (length) => new Float32Array(length));
		}
		/**
		* A helper method to create an {@link Autocorrelator} using
		* {@link Float64Array} buffers.
		*
		* @param inputLength {number} the input array length to support
		* @returns {Autocorrelator<Float64Array>}
		*/
		static forFloat64Array(inputLength) {
			return new Autocorrelator(inputLength, (length) => new Float64Array(length));
		}
		/**
		* A helper method to create an {@link Autocorrelator} using `number[]`
		* buffers.
		*
		* @param inputLength {number} the input array length to support
		* @returns {Autocorrelator<number[]>}
		*/
		static forNumberArray(inputLength) {
			return new Autocorrelator(inputLength, (length) => Array(length));
		}
		/**
		* Constructs a new {@link Autocorrelator} able to handle input arrays of the
		* given length.
		*
		* @param inputLength {number} the input array length to support. This
		* `Autocorrelator` will only support operation on arrays of this length.
		* @param bufferSupplier {(length: number) => T} the function to use for
		* creating buffers, accepting the length of the buffer to create and
		* returning a new buffer of that length. The values of the returned buffer
		* need not be initialized in any particular way.
		*/
		constructor(inputLength, bufferSupplier) {
			_defineProperty(
				this,
				/** @private @readonly @type {number} */
				"_inputLength",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {FFT} */
				"_fft",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {(size: number) => T} */
				"_bufferSupplier",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {T} */
				"_paddedInputBuffer",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {T} */
				"_transformBuffer",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {T} */
				"_inverseBuffer",
				void 0
			);
			if (inputLength < 1) throw new Error(`Input length must be at least one`);
			this._inputLength = inputLength;
			this._fft = new import_fft.default(ceilPow2(2 * inputLength));
			this._bufferSupplier = bufferSupplier;
			this._paddedInputBuffer = this._bufferSupplier(this._fft.size);
			this._transformBuffer = this._bufferSupplier(2 * this._fft.size);
			this._inverseBuffer = this._bufferSupplier(2 * this._fft.size);
		}
		/**
		* Returns the supported input length.
		*
		* @returns {number} the supported input length
		*/
		get inputLength() {
			return this._inputLength;
		}
		/**
		* Autocorrelates the given input data.
		*
		* @param input {ArrayLike<number>} the input data to autocorrelate
		* @param output {T} the output buffer into which to write the autocorrelated
		* data. If not provided, a new buffer will be created.
		* @returns {T} `output`
		*/
		autocorrelate(input, output = this._bufferSupplier(input.length)) {
			if (input.length !== this._inputLength) throw new Error(`Input must have length ${this._inputLength} but had length ${input.length}`);
			for (let i = 0; i < input.length; i++) this._paddedInputBuffer[i] = input[i];
			for (let i = input.length; i < this._paddedInputBuffer.length; i++) this._paddedInputBuffer[i] = 0;
			this._fft.realTransform(this._transformBuffer, this._paddedInputBuffer);
			this._fft.completeSpectrum(this._transformBuffer);
			const tb = this._transformBuffer;
			for (let i = 0; i < tb.length; i += 2) {
				tb[i] = tb[i] * tb[i] + tb[i + 1] * tb[i + 1];
				tb[i + 1] = 0;
			}
			this._fft.inverseTransform(this._inverseBuffer, this._transformBuffer);
			for (let i = 0; i < input.length; i++) output[i] = this._inverseBuffer[2 * i];
			return output;
		}
	};
	/**
	* Returns an array of all the key maximum positions in the given input array.
	*
	* In McLeod's paper, a key maximum is the highest maximum between a positively
	* sloped zero crossing and a negatively sloped one.
	*
	* TODO: it may be more efficient not to construct a new output array each time,
	* but that would also make the code more complicated (more so than the changes
	* that were needed to remove the other allocations).
	*
	* @param input {ArrayLike<number>}
	* @returns {number[]}
	*/
	function getKeyMaximumIndices(input) {
		/** @type {number[]} */ const keyIndices = [];
		let lookingForMaximum = false;
		let max = -Infinity;
		let maxIndex = -1;
		for (let i = 1; i < input.length - 1; i++) if (input[i - 1] <= 0 && input[i] > 0) {
			lookingForMaximum = true;
			maxIndex = i;
			max = input[i];
		} else if (input[i - 1] > 0 && input[i] <= 0) {
			lookingForMaximum = false;
			if (maxIndex !== -1) keyIndices.push(maxIndex);
		} else if (lookingForMaximum && input[i] > max) {
			max = input[i];
			maxIndex = i;
		}
		return keyIndices;
	}
	/**
	* Refines the chosen key maximum index chosen from the given data by
	* interpolating a parabola using the key maximum index and its two neighbors
	* and finding the position of that parabola's maximum value.
	*
	* This is described in section 5 of the MPM paper as a way to refine the
	* position of the maximum.
	*
	* @param index {number} the chosen key maximum index. This must be between `1`
	* and `data.length - 2`, inclusive, since it and its two neighbors need to be
	* valid indexes of `data`.
	* @param data {ArrayLike<number>} the input array from which `index` was chosen
	* @returns {[number, number]} a pair consisting of the refined key maximum index and the
	* interpolated value of `data` at that index (the latter of which is used as a
	* measure of clarity)
	*/
	function refineResultIndex(index, data) {
		const [x0, x1, x2] = [
			index - 1,
			index,
			index + 1
		];
		const [y0, y1, y2] = [
			data[x0],
			data[x1],
			data[x2]
		];
		const a = y0 / 2 - y1 + y2 / 2;
		const b = -(y0 / 2) * (x1 + x2) + y1 * (x0 + x2) - y2 / 2 * (x0 + x1);
		const c = y0 * x1 * x2 / 2 - y1 * x0 * x2 + y2 * x0 * x1 / 2;
		const xMax = -b / (2 * a);
		return [xMax, a * xMax * xMax + b * xMax + c];
	}
	/**
	* A class that can detect the pitch of a note from a time-domain input array.
	*
	* This class uses the McLeod pitch method (MPM) to detect pitches. MPM is
	* described in the paper 'A Smarter Way to Find Pitch' by Philip McLeod and
	* Geoff Wyvill
	* (http://miracle.otago.ac.nz/tartini/papers/A_Smarter_Way_to_Find_Pitch.pdf).
	*
	* The class holds internal buffers so that a minimal number of additional
	* allocations are necessary while performing the operation.
	*
	* @template {Buffer} T the buffer type to use internally. Inputs to the
	* pitch-detection process can be any numeric array type.
	*/
	var PitchDetector = class PitchDetector {
		/**
		* A helper method to create an {@link PitchDetector} using {@link Float32Array} buffers.
		*
		* @param inputLength {number} the input array length to support
		* @returns {PitchDetector<Float32Array>}
		*/
		static forFloat32Array(inputLength) {
			return new PitchDetector(inputLength, (length) => new Float32Array(length));
		}
		/**
		* A helper method to create an {@link PitchDetector} using {@link Float64Array} buffers.
		*
		* @param inputLength {number} the input array length to support
		* @returns {PitchDetector<Float64Array>}
		*/
		static forFloat64Array(inputLength) {
			return new PitchDetector(inputLength, (length) => new Float64Array(length));
		}
		/**
		* A helper method to create an {@link PitchDetector} using `number[]` buffers.
		*
		* @param inputLength {number} the input array length to support
		* @returns {PitchDetector<number[]>}
		*/
		static forNumberArray(inputLength) {
			return new PitchDetector(inputLength, (length) => Array(length));
		}
		/**
		* Constructs a new {@link PitchDetector} able to handle input arrays of the
		* given length.
		*
		* @param inputLength {number} the input array length to support. This
		* `PitchDetector` will only support operation on arrays of this length.
		* @param bufferSupplier {(inputLength: number) => T} the function to use for
		* creating buffers, accepting the length of the buffer to create and
		* returning a new buffer of that length. The values of the returned buffer
		* need not be initialized in any particular way.
		*/
		constructor(inputLength, bufferSupplier) {
			_defineProperty(
				this,
				/** @private @type {Autocorrelator<T>} */
				"_autocorrelator",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {T} */
				"_nsdfBuffer",
				void 0
			);
			_defineProperty(
				this,
				/** @private @type {number} */
				"_clarityThreshold",
				.9
			);
			_defineProperty(
				this,
				/** @private @type {number} */
				"_minVolumeAbsolute",
				0
			);
			_defineProperty(
				this,
				/** @private @type {number} */
				"_maxInputAmplitude",
				1
			);
			this._autocorrelator = new Autocorrelator(inputLength, bufferSupplier);
			this._nsdfBuffer = bufferSupplier(inputLength);
		}
		/**
		* Returns the supported input length.
		*
		* @returns {number} the supported input length
		*/
		get inputLength() {
			return this._autocorrelator.inputLength;
		}
		/**
		* Sets the clarity threshold used when identifying the correct pitch (the constant
		* `k` from the MPM paper). The value must be between 0 (exclusive) and 1
		* (inclusive), with the most suitable range being between 0.8 and 1.
		*
		* @param threshold {number} the clarity threshold
		*/
		set clarityThreshold(threshold) {
			if (!Number.isFinite(threshold) || threshold <= 0 || threshold > 1) throw new Error("clarityThreshold must be a number in the range (0, 1]");
			this._clarityThreshold = threshold;
		}
		/**
		* Sets the minimum detectable volume, as an absolute number between 0 and
		* `maxInputAmplitude`, inclusive, to consider in a sample when detecting the
		* pitch. If a sample fails to meet this minimum volume, `findPitch` will
		* return a clarity of 0.
		*
		* Volume is calculated as the RMS (root mean square) of the input samples.
		*
		* @param volume {number} the minimum volume as an absolute amplitude value
		*/
		set minVolumeAbsolute(volume) {
			if (!Number.isFinite(volume) || volume < 0 || volume > this._maxInputAmplitude) throw new Error(`minVolumeAbsolute must be a number in the range [0, ${this._maxInputAmplitude}]`);
			this._minVolumeAbsolute = volume;
		}
		/**
		* Sets the minimum volume using a decibel measurement. Must be less than or
		* equal to 0: 0 indicates the loudest possible sound (see
		* `maxInputAmplitude`), -10 is a sound with a tenth of the volume of the
		* loudest possible sound, etc.
		*
		* Volume is calculated as the RMS (root mean square) of the input samples.
		*
		* @param db {number} the minimum volume in decibels, with 0 being the loudest
		* sound
		*/
		set minVolumeDecibels(db) {
			if (!Number.isFinite(db) || db > 0) throw new Error("minVolumeDecibels must be a number <= 0");
			this._minVolumeAbsolute = this._maxInputAmplitude * 10 ** (db / 10);
		}
		/**
		* Sets the maximum amplitude of an input reading. Must be greater than 0.
		*
		* @param amplitude {number} the maximum amplitude (absolute value) of an input reading
		*/
		set maxInputAmplitude(amplitude) {
			if (!Number.isFinite(amplitude) || amplitude <= 0) throw new Error("maxInputAmplitude must be a number > 0");
			this._maxInputAmplitude = amplitude;
		}
		/**
		* Returns the pitch detected using McLeod Pitch Method (MPM) along with a
		* measure of its clarity.
		*
		* The clarity is a value between 0 and 1 (potentially inclusive) that
		* represents how "clear" the pitch was. A clarity value of 1 indicates that
		* the pitch was very distinct, while lower clarity values indicate less
		* definite pitches.
		*
		* @param input {ArrayLike<number>} the time-domain input data
		* @param sampleRate {number} the sample rate at which the input data was
		* collected
		* @returns {[number, number]} the detected pitch, in Hz, followed by the
		* clarity. If a pitch cannot be determined from the input, such as if the
		* volume is too low (see `minVolumeAbsolute` and `minVolumeDecibels`), this
		* will be `[0, 0]`.
		*/
		findPitch(input, sampleRate) {
			if (this._belowMinimumVolume(input)) return [0, 0];
			this._nsdf(input);
			const keyMaximumIndices = getKeyMaximumIndices(this._nsdfBuffer);
			if (keyMaximumIndices.length === 0) return [0, 0];
			const nMax = Math.max(...keyMaximumIndices.map((i) => this._nsdfBuffer[i]));
			const [refinedResultIndex, clarity] = refineResultIndex(keyMaximumIndices.find((i) => this._nsdfBuffer[i] >= this._clarityThreshold * nMax), this._nsdfBuffer);
			return [sampleRate / refinedResultIndex, Math.min(clarity, 1)];
		}
		/**
		* Returns whether the input audio data is below the minimum volume allowed by
		* the pitch detector.
		*
		* @private
		* @param input {ArrayLike<number>}
		* @returns {boolean}
		*/
		_belowMinimumVolume(input) {
			if (this._minVolumeAbsolute === 0) return false;
			let squareSum = 0;
			for (let i = 0; i < input.length; i++) squareSum += input[i] ** 2;
			return Math.sqrt(squareSum / input.length) < this._minVolumeAbsolute;
		}
		/**
		* Computes the NSDF of the input and stores it in the internal buffer. This
		* is equation (9) in the McLeod pitch method paper.
		*
		* @private
		* @param input {ArrayLike<number>}
		*/
		_nsdf(input) {
			this._autocorrelator.autocorrelate(input, this._nsdfBuffer);
			let m = 2 * this._nsdfBuffer[0];
			/** @type {number} */ let i = 0;
			for (; i < this._nsdfBuffer.length && m > 0; i++) {
				this._nsdfBuffer[i] = 2 * this._nsdfBuffer[i] / m;
				m -= input[i] ** 2 + input[input.length - i - 1] ** 2;
			}
			for (; i < this._nsdfBuffer.length; i++) this._nsdfBuffer[i] = 0;
		}
	};
	/**
	* Rounds up the input to the next power of 2.
	*
	* @param {number} v
	* @returns {number} the next power of 2 at least as large as `v`
	*/
	function ceilPow2(v) {
		v--;
		v |= v >> 1;
		v |= v >> 2;
		v |= v >> 4;
		v |= v >> 8;
		v |= v >> 16;
		v++;
		return v;
	}
	//#endregion
	//#region voice-pitch.js
	var NOTES = [
		"C",
		"C#",
		"D",
		"D#",
		"E",
		"F",
		"F#",
		"G",
		"G#",
		"A",
		"A#",
		"B"
	];
	var VOICE_MAX_PITCH = 2200;
	var REQUIRED_STABLE_FRAMES = 2;
	var STABLE_TOLERANCE_SEMITONES = 1.2;
	function frequencyToNote(hz) {
		if (!Number.isFinite(hz) || hz <= 0) return null;
		const midi = Math.round(69 + 12 * Math.log2(hz / 440));
		return `${NOTES[(midi % 12 + 12) % 12]}${Math.floor(midi / 12) - 1}`;
	}
	function createPitchRange() {
		return {
			minimum: null,
			maximum: null,
			candidate: null,
			consecutive: 0
		};
	}
	function trackPitch(range, hz) {
		if (!Number.isFinite(hz) || hz < 65 || hz > 2200) {
			range.candidate = null;
			range.consecutive = 0;
			return false;
		}
		if (range.candidate !== null && Math.abs(12 * Math.log2(hz / range.candidate)) < STABLE_TOLERANCE_SEMITONES) range.consecutive += 1;
		else range.consecutive = 1;
		range.candidate = hz;
		if (range.consecutive < REQUIRED_STABLE_FRAMES) return false;
		range.minimum = range.minimum === null ? hz : Math.min(range.minimum, hz);
		range.maximum = range.maximum === null ? hz : Math.max(range.maximum, hz);
		return true;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.150.0/helpers/esm/objectSpread2.js
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				_defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	var A_PAIR_INDEXES = [
		[0, 1],
		[0, 2],
		[1, 2],
		[1, 3],
		[2, 3],
		[2, 4],
		[3, 4],
		[3, 5],
		[4, 5],
		[4, 0]
	];
	var B_PAIR_INDEXES = [
		[0, 1],
		[1, 2],
		[2, 3],
		[3, 4],
		[4, 5]
	];
	function parsePsychologyImageAge(filename) {
		const match = decodeURIComponent(filename).match(/-(\d+(?:\.\d+)?)(?:\s*\(\d+\))?\.jpe?g$/i);
		if (!match) throw new Error(`无法从图片名读取年龄：${filename}`);
		return Number(match[1]);
	}
	function shufflePsychologyItems(items, random = Math.random) {
		const result = [...items];
		for (let index = result.length - 1; index > 0; index -= 1) {
			const other = Math.floor(random() * (index + 1));
			[result[index], result[other]] = [result[other], result[index]];
		}
		return result;
	}
	function labelGroup(items, prefix, random) {
		return shufflePsychologyItems(items, random).map((image, index) => _objectSpread2(_objectSpread2({}, image), {}, { label: `${prefix}${index + 1}` }));
	}
	function buildGroupRounds(group, pairIndexes, random, groupName) {
		return pairIndexes.map(([firstIndex, secondIndex]) => {
			const pair = [group[firstIndex], group[secondIndex]];
			if (random() < .5) pair.reverse();
			return {
				first: pair[0],
				second: pair[1],
				group: groupName
			};
		});
	}
	function createPsychologyRounds(favorites, relativeLessFavorites, random = Math.random) {
		if (favorites.length !== 6 || relativeLessFavorites.length !== 6) throw new Error("A 组和 B 组都必须正好包含 6 张图片");
		const groupA = labelGroup(favorites, "A", random);
		const groupB = labelGroup(relativeLessFavorites, "B", random);
		return [...buildGroupRounds(groupA, A_PAIR_INDEXES, random, "A"), ...buildGroupRounds(groupB, B_PAIR_INDEXES, random, "B")];
	}
	function scorePsychologyChoice(chosenAge, otherAge, elapsedMs, group) {
		if (![
			chosenAge,
			otherAge,
			elapsedMs
		].every(Number.isFinite) || elapsedMs < 0) throw new Error("年龄和作答时间必须是有效数字");
		if (group !== "A" && group !== "B") throw new Error("必须指定 A 或 B 组");
		const [chosenWeight, otherWeight] = (group === "A" ? [
			[2.2, .8],
			[1.9, 1.1],
			[1.6, 1.4]
		] : [
			[.85, .15],
			[.7, .3],
			[.6, .4]
		])[elapsedMs < 2e3 ? 0 : elapsedMs <= 5e3 ? 1 : 2];
		return chosenAge * chosenWeight + otherAge * otherWeight;
	}
	function averagePsychologyScores(scores) {
		if (scores.length !== 15 || !scores.every(Number.isFinite)) throw new Error("必须提供有效的轮次分数");
		return scores.reduce((sum, score) => sum + score, 0) / 35;
	}
	//#endregion
	//#region psychology-title.js
	var PSYCHOLOGY_TITLES = [
		[
			15,
			"幼年期",
			5
		],
		[
			20,
			"未发育",
			4
		],
		[
			25,
			"发育中",
			3
		],
		[
			30,
			"成熟期",
			2
		],
		[
			35,
			"完全体",
			1
		],
		[
			40,
			"究极体",
			0
		],
		[
			45,
			"中老年人",
			6
		],
		[
			50,
			"老年人",
			7
		]
	];
	function getPsychologyTitle(score) {
		var _PSYCHOLOGY_TITLES$fi, _PSYCHOLOGY_TITLES$fi2;
		if (score == null || !Number.isFinite(Number(score))) return "未获得";
		const age = Number(score);
		return (_PSYCHOLOGY_TITLES$fi = (_PSYCHOLOGY_TITLES$fi2 = PSYCHOLOGY_TITLES.find(([limit]) => age < limit)) === null || _PSYCHOLOGY_TITLES$fi2 === void 0 ? void 0 : _PSYCHOLOGY_TITLES$fi2[1]) !== null && _PSYCHOLOGY_TITLES$fi !== void 0 ? _PSYCHOLOGY_TITLES$fi : "待火化";
	}
	function getPsychologyLevelRank(score) {
		var _PSYCHOLOGY_TITLES$fi3, _PSYCHOLOGY_TITLES$fi4;
		if (score == null || !Number.isFinite(Number(score))) return null;
		const age = Number(score);
		return (_PSYCHOLOGY_TITLES$fi3 = (_PSYCHOLOGY_TITLES$fi4 = PSYCHOLOGY_TITLES.find(([limit]) => age < limit)) === null || _PSYCHOLOGY_TITLES$fi4 === void 0 ? void 0 : _PSYCHOLOGY_TITLES$fi4[2]) !== null && _PSYCHOLOGY_TITLES$fi3 !== void 0 ? _PSYCHOLOGY_TITLES$fi3 : 8;
	}
	//#endregion
	//#region psychology.js
	var psychologyImages = Object.entries({
		"./source/psychology/TFBOYS-22.jpg": "./assets/psychology-0.jpg",
		"./source/psychology/chiikawa-17.jpg": "./assets/psychology-1.jpg",
		"./source/psychology/momo-20.jpg": "./assets/psychology-2.jpg",
		"./source/psychology/五口之家-70.jpg": "./assets/psychology-3.jpg",
		"./source/psychology/周杰伦-35.jpg": "./assets/psychology-4.jpg",
		"./source/psychology/哆啦A梦-21.jpg": "./assets/psychology-5.jpg",
		"./source/psychology/大大怪-21.jpg": "./assets/psychology-6.jpg",
		"./source/psychology/小樱-31.jpg": "./assets/psychology-7.jpg",
		"./source/psychology/小猪佩奇-13.jpg": "./assets/psychology-8.jpg",
		"./source/psychology/小蓝姐姐-26.jpg": "./assets/psychology-9.jpg",
		"./source/psychology/张学友-48.jpg": "./assets/psychology-10.jpg",
		"./source/psychology/慕容云海-30.jpg": "./assets/psychology-11.jpg",
		"./source/psychology/成龙-31.jpg": "./assets/psychology-12.jpg",
		"./source/psychology/无名-40.jpg": "./assets/psychology-13.jpg",
		"./source/psychology/星际宝贝-28.jpg": "./assets/psychology-14.jpg",
		"./source/psychology/暖暖-19.jpg": "./assets/psychology-15.jpg",
		"./source/psychology/曼哈顿-36.jpg": "./assets/psychology-16.jpg",
		"./source/psychology/林品如-39.jpg": "./assets/psychology-17.jpg",
		"./source/psychology/梦叶罗丽-9.jpg": "./assets/psychology-18.jpg",
		"./source/psychology/汪汪队-11.jpg": "./assets/psychology-19.jpg",
		"./source/psychology/温馨-29.jpg": "./assets/psychology-20.jpg",
		"./source/psychology/火影忍者-31.jpg": "./assets/psychology-21.jpg",
		"./source/psychology/灵狐者-33.jpg": "./assets/psychology-22.jpg",
		"./source/psychology/熊二-14.jpg": "./assets/psychology-23.jpg",
		"./source/psychology/熊猫人-27.jpg": "./assets/psychology-24.jpg",
		"./source/psychology/牛爷爷-19.jpg": "./assets/psychology-25.jpg",
		"./source/psychology/猪猪侠-15.jpg": "./assets/psychology-26.jpg",
		"./source/psychology/猫-25.jpg": "./assets/psychology-27.jpg",
		"./source/psychology/猫和老鼠-23.jpg": "./assets/psychology-28.jpg",
		"./source/psychology/紫微-41.jpg": "./assets/psychology-29.jpg",
		"./source/psychology/美少女战士-36.jpg": "./assets/psychology-30.jpg",
		"./source/psychology/美食甜点-19.jpg": "./assets/psychology-31.jpg",
		"./source/psychology/花-50.jpg": "./assets/psychology-32.jpg",
		"./source/psychology/花二-38.jpg": "./assets/psychology-33.jpg",
		"./source/psychology/蔡徐坤-21.jpg": "./assets/psychology-34.jpg",
		"./source/psychology/贝吉塔-35.jpg": "./assets/psychology-35.jpg",
		"./source/psychology/超级飞侠-12.jpg": "./assets/psychology-36.jpg",
		"./source/psychology/郭德纲-54.jpg": "./assets/psychology-37.jpg",
		"./source/psychology/郭靖-45.jpg": "./assets/psychology-38.jpg",
		"./source/psychology/鞠婧祎-25.jpg": "./assets/psychology-39.jpg",
		"./source/psychology/黑猫警长-42.jpg": "./assets/psychology-40.jpg"
	}).map(([path, url]) => ({
		id: path,
		url,
		age: parsePsychologyImageAge(path)
	}));
	var STORAGE_KEY$2 = "lita-psychology-records";
	var MAX_RECORDS$1 = 30;
	function createElement$1(tag, className, text) {
		const element = document.createElement(tag);
		if (className) element.className = className;
		if (text !== void 0) element.textContent = text;
		return element;
	}
	function setupPsychologyTest({ formatDate, showToast }) {
		const content = document.querySelector("#psychology-content");
		const history = document.querySelector("#psychology-history");
		const stageLabel = document.querySelector("#psychology-stage-label");
		const stageMeta = document.querySelector("#psychology-stage-meta");
		const progressFill = document.querySelector("#psychology-progress-fill");
		const reportDialog = document.querySelector("#psychology-report-dialog");
		const reportTime = document.querySelector("#psychology-report-time");
		const reportScore = document.querySelector("#psychology-report-score");
		const reportDiagnosis = document.querySelector("#psychology-report-diagnosis");
		let phase = "idle";
		let firstSelection = /* @__PURE__ */ new Set();
		let favoriteSelection = /* @__PURE__ */ new Set();
		let imageOrder = [];
		let rounds = [];
		let roundIndex = 0;
		let roundStartedAt = 0;
		let roundLocked = false;
		let scores = [];
		function setProgress(label, meta, percent) {
			stageLabel.textContent = label;
			stageMeta.textContent = meta;
			progressFill.style.width = `${Math.max(0, Math.min(100, percent))}%`;
		}
		function readRecords() {
			try {
				const records = JSON.parse(localStorage.getItem(STORAGE_KEY$2) || "[]");
				return Array.isArray(records) ? records : [];
			} catch (_unused) {
				return [];
			}
		}
		function saveRecord(record) {
			try {
				localStorage.setItem(STORAGE_KEY$2, JSON.stringify([record, ...readRecords()].slice(0, MAX_RECORDS$1)));
			} catch (_unused2) {
				showToast("记录保存失败，请检查浏览器存储空间");
			}
		}
		function openReport(record) {
			reportTime.textContent = formatDate.format(new Date(record.time));
			reportScore.textContent = `${Number(record.score).toFixed(2)} 岁`;
			reportDiagnosis.textContent = getPsychologyTitle(record.score);
			reportDialog.showModal();
		}
		function renderHistory() {
			history.replaceChildren();
			const records = readRecords();
			if (!records.length) {
				history.append(createElement$1("p", "history-empty", "暂无记录"));
				return;
			}
			const header = createElement$1("div", "history-header psychology-history-header");
			header.append(createElement$1("span", "", "时间"), createElement$1("span", "", "心理年龄"), createElement$1("span", "", "级别"));
			history.append(header);
			records.forEach((record) => {
				const row = createElement$1("button", "history-row psychology-history-row");
				row.type = "button";
				row.setAttribute("aria-label", `查看 ${formatDate.format(new Date(record.time))} 的心理年龄测试报告`);
				const time = createElement$1("time", "", formatDate.format(new Date(record.time)));
				time.dateTime = record.time;
				const score = createElement$1("strong", "", `${Number(record.score).toFixed(2)} 岁`);
				const title = createElement$1("strong", `level-badge ${getLevelBadgeClass(getPsychologyLevelRank(record.score))}`, getPsychologyTitle(record.score));
				row.append(time, score, title);
				row.addEventListener("click", () => openReport(record));
				history.append(row);
			});
		}
		function updateSelectionState(selected, required, count, button, cards) {
			count.textContent = `${selected.size} / ${required}`;
			button.disabled = selected.size !== required;
			cards.forEach(({ image, card }) => {
				const isSelected = selected.has(image.id);
				card.classList.toggle("is-selected", isSelected);
				card.setAttribute("aria-pressed", String(isSelected));
			});
		}
		function renderImageSelection({ images, selected, required, title, description, actionLabel, onContinue }) {
			content.replaceChildren();
			const section = createElement$1("section", "psychology-selection");
			const heading = createElement$1("h2", "psychology-selection-title", title);
			const note = createElement$1("p", "psychology-selection-note", description);
			const grid = createElement$1("div", "psychology-image-grid");
			const cards = [];
			images.forEach((image, index) => {
				const card = createElement$1("button", "psychology-image-choice");
				card.type = "button";
				card.setAttribute("aria-pressed", "false");
				card.setAttribute("aria-label", `备选图片 ${index + 1}`);
				const picture = document.createElement("img");
				picture.src = image.url;
				picture.alt = "";
				picture.loading = index < 6 ? "eager" : "lazy";
				picture.decoding = "async";
				const check = createElement$1("span", "psychology-image-check", "✓");
				card.append(picture, check);
				card.addEventListener("click", () => {
					if (selected.has(image.id)) selected.delete(image.id);
					else if (selected.size < required) selected.add(image.id);
					else {
						showToast(`最多选择 ${required} 张图片`);
						return;
					}
					updateSelectionState(selected, required, count, continueButton, cards);
				});
				cards.push({
					image,
					card
				});
				grid.append(card);
			});
			const action = createElement$1("div", "psychology-selection-action");
			const countWrap = createElement$1("span", "psychology-select-count", "已选择 ");
			const count = createElement$1("strong", "", `0 / ${required}`);
			countWrap.append(count);
			const continueButton = createElement$1("button", "play-button", actionLabel);
			continueButton.type = "button";
			continueButton.disabled = true;
			continueButton.addEventListener("click", onContinue);
			action.append(countWrap, continueButton);
			section.append(heading, note, grid, action);
			content.append(section);
			updateSelectionState(selected, required, count, continueButton, cards);
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		}
		function renderFirstSelection() {
			phase = "first-selection";
			setProgress("图片初选", "第 1 步，共 3 步", 12);
			renderImageSelection({
				images: imageOrder,
				selected: firstSelection,
				required: 12,
				title: "凭直觉选出最喜欢的 12 张",
				description: "不需要考虑图片代表什么，选择第一眼让你更有好感的图片。",
				actionLabel: "下一步",
				onContinue: renderFavoriteSelection
			});
		}
		function renderFavoriteSelection() {
			phase = "favorite-selection";
			favoriteSelection = /* @__PURE__ */ new Set();
			setProgress("再次精选", "第 2 步，共 3 步", 34);
			renderImageSelection({
				images: shufflePsychologyItems(imageOrder.filter((image) => firstSelection.has(image.id))),
				selected: favoriteSelection,
				required: 6,
				title: "再选出更喜欢的 6 张",
				description: "这一次只比较刚才选出的图片，选择其中相对更喜欢的 6 张。",
				actionLabel: "开始偏好对比",
				onContinue: beginComparisons
			});
		}
		function beginComparisons() {
			const chosenImages = imageOrder.filter((image) => firstSelection.has(image.id));
			rounds = createPsychologyRounds(chosenImages.filter((image) => favoriteSelection.has(image.id)), chosenImages.filter((image) => !favoriteSelection.has(image.id)));
			roundIndex = 0;
			scores = [];
			phase = "comparison";
			renderComparison();
		}
		function chooseComparison(chosen) {
			if (roundLocked || phase !== "comparison") return;
			roundLocked = true;
			const elapsedMs = Math.max(0, performance.now() - roundStartedAt);
			const round = rounds[roundIndex];
			const other = chosen.label === round.first.label ? round.second : round.first;
			const score = scorePsychologyChoice(chosen.age, other.age, elapsedMs, round.group);
			scores.push(score);
			console.debug("[心理年龄测试] 单轮计分", {
				round: roundIndex + 1,
				group: round.group,
				pair: `${round.first.label}/${round.second.label}`,
				chosen: chosen.label,
				elapsedSeconds: Number((elapsedMs / 1e3).toFixed(3)),
				chosenAge: chosen.age,
				otherAge: other.age,
				score: Number(score.toFixed(4))
			});
			roundIndex += 1;
			if (roundIndex >= rounds.length) finishTest();
			else renderComparison();
		}
		function createPairChoice(image, position) {
			const button = createElement$1("button", "psychology-pair-choice");
			button.type = "button";
			button.setAttribute("aria-label", `选择${position === 0 ? "左边" : "右边"}的图片`);
			const picture = document.createElement("img");
			picture.src = image.url;
			picture.alt = "";
			picture.decoding = "async";
			button.append(picture, createElement$1("span", "", "选择这张"));
			button.addEventListener("click", () => chooseComparison(image));
			return button;
		}
		function renderComparison() {
			roundLocked = false;
			const round = rounds[roundIndex];
			const completed = roundIndex;
			setProgress("偏好对比", `第 ${roundIndex + 1} / ${rounds.length} 组`, 34 + completed / rounds.length * 66);
			content.replaceChildren();
			const section = createElement$1("section", "psychology-comparison");
			section.append(createElement$1("p", "psychology-eyebrow", "凭第一感觉选择"), createElement$1("h2", "psychology-comparison-title", "哪一张更喜欢？"), createElement$1("p", "psychology-comparison-note", "点击相对更有好感的一张，不必反复比较。"));
			const pair = createElement$1("div", "psychology-pair-grid");
			pair.append(createPairChoice(round.first, 0), createPairChoice(round.second, 1));
			section.append(pair);
			content.append(section);
			roundStartedAt = performance.now();
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		}
		function finishTest() {
			const rawScore = averagePsychologyScores(scores);
			const score = Number(rawScore.toFixed(2));
			const record = {
				time: (/* @__PURE__ */ new Date()).toISOString(),
				score
			};
			console.debug("[心理年龄测试] 最终计分", {
				rounds: scores.map((value) => Number(value.toFixed(4))),
				total: Number(scores.reduce((sum, value) => sum + value, 0).toFixed(4)),
				average: rawScore,
				displayedScore: score
			});
			saveRecord(record);
			renderHistory();
			phase = "result";
			setProgress("测试完成", "结果已生成", 100);
			content.replaceChildren();
			const result = createElement$1("section", "psychology-result");
			result.append(createElement$1("p", "psychology-eyebrow", "你的测试结果"), createElement$1("h2", "psychology-result-title", "心理年龄"));
			const value = createElement$1("div", "psychology-result-value");
			value.append(createElement$1("strong", "", score.toFixed(2)), createElement$1("span", "", "岁"));
			result.append(value, createElement$1("p", "psychology-result-note", "结果来自本次视觉偏好与选择反应，仅供趣味参考。"));
			const actions = createElement$1("div", "psychology-result-actions");
			const restart = createElement$1("button", "play-button", "再测一次");
			restart.type = "button";
			restart.addEventListener("click", startTest);
			const records = createElement$1("button", "psychology-secondary-button", "返回历史记录");
			records.type = "button";
			records.addEventListener("click", () => {
				location.hash = "psychology";
			});
			actions.append(restart, records);
			result.append(actions);
			content.append(result);
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		}
		function startTest() {
			if (psychologyImages.length < 12) {
				showToast("测试图片数量不足");
				return;
			}
			imageOrder = shufflePsychologyItems(psychologyImages);
			firstSelection = /* @__PURE__ */ new Set();
			favoriteSelection = /* @__PURE__ */ new Set();
			rounds = [];
			scores = [];
			roundIndex = 0;
			renderFirstSelection();
		}
		function ensureStarted() {
			if (phase === "idle") startTest();
		}
		function leaveTest() {
			phase = "idle";
			roundLocked = true;
			content.replaceChildren();
		}
		document.querySelector("#psychology-start").addEventListener("click", () => {
			location.hash = "psychology-test";
		});
		document.querySelector("#psychology-report-close").addEventListener("click", () => reportDialog.close());
		reportDialog.addEventListener("click", (event) => {
			if (event.target === reportDialog) reportDialog.close();
		});
		renderHistory();
		return {
			ensureStarted,
			leaveTest,
			renderHistory
		};
	}
	var VISION_SIZE_STEP = .5;
	function createVisionTest() {
		return {
			size: 100,
			invisibleLowerBound: .5,
			visibleUpperBound: 100,
			upperBoundConfirmed: false,
			correctStreak: 0,
			wrongStreak: 0,
			trials: 0,
			decisions: 0,
			phase: "testing",
			result: null
		};
	}
	function finishOrSelectNext(test) {
		if (test.visibleUpperBound - test.invisibleLowerBound <= .5) {
			if (test.upperBoundConfirmed || test.invisibleLowerBound >= test.visibleUpperBound) {
				test.phase = "done";
				test.result = test.upperBoundConfirmed ? test.visibleUpperBound : null;
			} else test.size = test.visibleUpperBound;
			return;
		}
		const midpoint = (test.invisibleLowerBound + test.visibleUpperBound) / 2;
		test.size = Math.floor(midpoint / VISION_SIZE_STEP) * VISION_SIZE_STEP;
	}
	function answerVisionTrial(test, correct) {
		if (test.phase !== "testing") throw new Error("视觉测试已经结束");
		if (typeof correct !== "boolean") throw new TypeError("correct 必须是布尔值");
		const previousSize = test.size;
		test.trials += 1;
		if (correct) {
			test.correctStreak += 1;
			test.wrongStreak = 0;
		} else {
			test.wrongStreak += 1;
			test.correctStreak = 0;
		}
		let decision = null;
		if (test.correctStreak >= 3) {
			decision = "visible";
			test.visibleUpperBound = test.size;
			test.upperBoundConfirmed = true;
		} else if (test.wrongStreak >= 2) {
			decision = "invisible";
			test.invisibleLowerBound = test.size;
		}
		if (decision) {
			test.correctStreak = 0;
			test.wrongStreak = 0;
			test.decisions += 1;
			finishOrSelectNext(test);
		}
		return {
			correct,
			decision,
			sizeChanged: test.size !== previousSize,
			done: test.phase === "done",
			result: test.result
		};
	}
	//#endregion
	//#region vision-title.js
	function getVisionLevel(score) {
		if (score === null) return {
			title: "纯瞎",
			rank: 12
		};
		if (!Number.isFinite(Number(score))) return {
			title: "未获得",
			rank: null
		};
		const size = Number(score);
		if (size > 100) return {
			title: "纯瞎",
			rank: 12
		};
		if (size > 50) return {
			title: "半瞎",
			rank: 11
		};
		if (size > 25) return {
			title: "选择性瞎",
			rank: 10
		};
		if (size > 12) return {
			title: "不瞎",
			rank: 9
		};
		if (size > 6) return {
			title: "老花眼",
			rank: 8
		};
		if (size > 4) return {
			title: "入门眼",
			rank: 7
		};
		if (size >= 4) return {
			title: "大众眼",
			rank: 6
		};
		if (size >= 3.5) return {
			title: "青铜眼",
			rank: 5
		};
		if (size >= 3) return {
			title: "白银眼",
			rank: 4
		};
		if (size >= 2.5) return {
			title: "黄金眼",
			rank: 3
		};
		if (size >= 2) return {
			title: "白金眼",
			rank: 2
		};
		if (size >= 1.5) return {
			title: "钻石眼",
			rank: 1
		};
		return {
			title: "天眼",
			rank: 0
		};
	}
	function getVisionTitle(score) {
		return getVisionLevel(score).title;
	}
	function getVisionLevelRank(score) {
		return getVisionLevel(score).rank;
	}
	//#endregion
	//#region vision.js
	var STORAGE_KEY$1 = "lita-vision-records";
	var MAX_RECORDS = 30;
	var DIRECTIONS = [
		{
			id: "right",
			rotation: 0
		},
		{
			id: "down",
			rotation: 90
		},
		{
			id: "left",
			rotation: 180
		},
		{
			id: "up",
			rotation: 270
		}
	];
	function createElement(tag, className, text) {
		const element = document.createElement(tag);
		if (className) element.className = className;
		if (text !== void 0) element.textContent = text;
		return element;
	}
	function setupVisionTest({ formatDate, showToast }) {
		const session = document.querySelector("#vision-test-session");
		const resultPanel = document.querySelector("#vision-result");
		const optotype = document.querySelector("#vision-optotype");
		const trialCount = document.querySelector("#vision-trial-count");
		const currentSize = document.querySelector("#vision-current-size");
		const status = document.querySelector("#vision-status");
		const directionPad = document.querySelector("#vision-direction-pad");
		const history = document.querySelector("#vision-history");
		const resultScore = document.querySelector("#vision-result-score");
		const resultNote = document.querySelector("#vision-result-note");
		const reportDialog = document.querySelector("#vision-report-dialog");
		const reportTime = document.querySelector("#vision-report-time");
		const reportScore = document.querySelector("#vision-report-score");
		const reportDiagnosis = document.querySelector("#vision-report-diagnosis");
		let testState = null;
		let currentDirection = null;
		let acceptingAnswer = false;
		function readRecords() {
			try {
				const records = JSON.parse(localStorage.getItem(STORAGE_KEY$1) || "[]");
				return Array.isArray(records) ? records : [];
			} catch (_unused) {
				return [];
			}
		}
		function scoreLabel(record) {
			var _record$maximumSize;
			if (record.score !== null) return `${record.score} L`;
			return `> ${(_record$maximumSize = record.maximumSize) !== null && _record$maximumSize !== void 0 ? _record$maximumSize : 200} L`;
		}
		function saveRecord(record) {
			try {
				localStorage.setItem(STORAGE_KEY$1, JSON.stringify([record, ...readRecords()].slice(0, MAX_RECORDS)));
			} catch (_unused2) {
				showToast("记录保存失败，请检查浏览器存储空间");
			}
		}
		function openReport(record) {
			reportTime.textContent = formatDate.format(new Date(record.time));
			reportScore.textContent = scoreLabel(record);
			reportDiagnosis.textContent = getVisionTitle(record.score);
			reportDialog.showModal();
		}
		function renderHistory() {
			history.replaceChildren();
			const records = readRecords();
			if (!records.length) {
				history.append(createElement("p", "history-empty", "暂无记录"));
				return;
			}
			const header = createElement("div", "history-header vision-history-header");
			header.append(createElement("span", "", "时间"), createElement("span", "", "测试结果"), createElement("span", "", "级别"));
			history.append(header);
			records.forEach((record) => {
				const row = createElement("button", "history-row vision-history-row");
				row.type = "button";
				row.setAttribute("aria-label", `查看 ${formatDate.format(new Date(record.time))} 的视觉测试报告`);
				const time = createElement("time", "", formatDate.format(new Date(record.time)));
				time.dateTime = record.time;
				const title = createElement("strong", `level-badge ${getLevelBadgeClass(getVisionLevelRank(record.score))}`, getVisionTitle(record.score));
				row.append(time, createElement("strong", "", scoreLabel(record)), title);
				row.addEventListener("click", () => openReport(record));
				history.append(row);
			});
		}
		function chooseDirection() {
			const choices = DIRECTIONS.filter((direction) => direction.id !== (currentDirection === null || currentDirection === void 0 ? void 0 : currentDirection.id));
			currentDirection = choices[Math.floor(Math.random() * choices.length)];
		}
		function renderTrial(message = "请选择 E 的开口方向") {
			chooseDirection();
			optotype.style.width = `${testState.size}px`;
			optotype.style.height = `${testState.size}px`;
			optotype.style.transform = `rotate(${currentDirection.rotation}deg)`;
			trialCount.textContent = `第 ${testState.trials + 1} 次判断`;
			currentSize.textContent = `当前：${testState.size}L`;
			status.textContent = message;
			acceptingAnswer = true;
		}
		function finishTest() {
			saveRecord({
				time: (/* @__PURE__ */ new Date()).toISOString(),
				score: testState.result,
				maximumSize: 100
			});
			renderHistory();
			session.hidden = true;
			resultPanel.hidden = false;
			resultScore.textContent = testState.result === null ? `> 100` : String(testState.result);
			resultNote.textContent = testState.result === null ? "在当前测试范围内未能稳定辨认，请调整距离或光线后重试。" : "数值越小，代表能够辨认越小的方向视标。";
			console.debug("[视觉测试] 测试完成", {
				score: testState.result,
				trials: testState.trials,
				decisions: testState.decisions
			});
		}
		function answer(direction) {
			if (!acceptingAnswer || !testState || testState.phase !== "testing") return;
			acceptingAnswer = false;
			const displayedSize = testState.size;
			const displayedDirection = currentDirection.id;
			const correct = direction === displayedDirection;
			const outcome = answerVisionTrial(testState, correct);
			console.debug("[视觉测试] 单次判断", {
				trial: testState.trials,
				size: displayedSize,
				direction: displayedDirection,
				answer: direction,
				correct,
				decision: outcome.decision,
				nextSize: testState.size
			});
			if (outcome.done) {
				finishTest();
				return;
			}
			renderTrial(outcome.decision ? "尺寸已调整，请继续判断" : "方向已记录，请再判断一次");
		}
		function startTest() {
			testState = createVisionTest();
			currentDirection = null;
			session.hidden = false;
			resultPanel.hidden = true;
			renderTrial();
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		}
		function ensureStarted() {
			if (!testState) startTest();
		}
		function leaveTest() {
			testState = null;
			currentDirection = null;
			acceptingAnswer = false;
			session.hidden = false;
			resultPanel.hidden = true;
		}
		document.querySelector("#vision-start").addEventListener("click", () => {
			location.hash = "vision-test";
		});
		directionPad.addEventListener("click", (event) => {
			const button = event.target.closest("button[data-direction]");
			if (button) answer(button.dataset.direction);
		});
		document.querySelector("#vision-restart").addEventListener("click", startTest);
		document.querySelector("#vision-result-back").addEventListener("click", () => {
			location.hash = "vision";
		});
		document.querySelector("#vision-report-close").addEventListener("click", () => reportDialog.close());
		reportDialog.addEventListener("click", (event) => {
			if (event.target === reportDialog) reportDialog.close();
		});
		renderHistory();
		return {
			ensureStarted,
			leaveTest,
			renderHistory
		};
	}
	//#endregion
	//#region xhs/save-report.js
	function bindReportSave(button, outputImage, showToast) {
		let saving = false;
		button.addEventListener("click", async () => {
			if (saving || !outputImage.src.startsWith("data:image/")) return;
			const bridge = window.xhs && window.xhs.miniTool;
			if (!bridge || !bridge.writeTempFile || !bridge.saveImageToPhotosAlbum) {
				showToast("请在小红书小工具中保存到相册");
				return;
			}
			saving = true;
			button.disabled = true;
			button.textContent = "正在保存…";
			try {
				const result = await bridge.writeTempFile({ data: outputImage.src });
				if (!result || !result.filePath) throw new Error("未取得图片文件");
				await bridge.saveImageToPhotosAlbum({ filePath: result.filePath });
				showToast("报告已保存到相册");
			} catch (error) {
				showToast("保存失败，请检查相册权限后重试");
				console.warn("报告保存失败", error && (error.errMsg || error.message));
			} finally {
				saving = false;
				button.disabled = false;
				button.textContent = "保存报告图片";
			}
		});
	}
	//#endregion
	//#region certificate-data.js
	var CERTIFICATE_TITLES = {
		report: "检查报告",
		health: "健康证明",
		forged: "健康证明（非伪造）"
	};
	function findLatestRecord(records) {
		if (!Array.isArray(records) || records.length === 0) return null;
		return records.reduce((latest, record) => {
			if (!latest) return record;
			return Date.parse(record.time) > Date.parse(latest.time) ? record : latest;
		}, null);
	}
	function formatHearingResult(record) {
		if (!record || !Number.isFinite(record.minimum) || !Number.isFinite(record.maximum)) return "未测试";
		return `${Math.round(record.minimum)}Hz~${Math.round(record.maximum)}Hz(${getHearingTitle(record.maximum)})`;
	}
	function formatVoiceResult(record) {
		if (!record || !Number.isFinite(record.minimum) || !Number.isFinite(record.maximum)) return "未测试";
		return `${Math.round(record.minimum)}Hz~${Math.round(record.maximum)}Hz(${getVoiceTitle(record.maximum)})`;
	}
	function formatPsychologyResult(record) {
		if (!record || record.score == null || !Number.isFinite(Number(record.score))) return "未测试";
		return `${Number(record.score).toFixed(2)}岁(${getPsychologyTitle(record.score)})`;
	}
	function formatVisionResult(record) {
		var _record$maximumSize;
		if (!record || !(record.score === null || Number.isFinite(Number(record.score)))) return "未测试";
		return `${record.score === null ? `>${(_record$maximumSize = record.maximumSize) !== null && _record$maximumSize !== void 0 ? _record$maximumSize : 200}L` : `${Number(record.score)}L`}(${getVisionTitle(record.score)})`;
	}
	function buildCertificateResults(recordGroups) {
		return {
			hearing: formatHearingResult(findLatestRecord(recordGroups.hearing)),
			voice: formatVoiceResult(findLatestRecord(recordGroups.voice)),
			psychology: formatPsychologyResult(findLatestRecord(recordGroups.psychology)),
			vision: formatVisionResult(findLatestRecord(recordGroups.vision))
		};
	}
	//#endregion
	//#region certificate.js
	var STORAGE_KEYS = {
		hearing: "lita-hearing-records",
		voice: "lita-voice-records",
		psychology: "lita-psychology-records",
		vision: "lita-vision-records"
	};
	var RESULT_LABELS = {
		hearing: "听力范围",
		voice: "音调范围",
		psychology: "心理年龄",
		vision: "视觉分数"
	};
	var CERTIFICATE_THEMES = {
		green: {
			paper: "#fffdf8",
			header: "#203d39",
			title: "#fffdf8",
			ink: "#203d39",
			accent: "#d6bc84",
			stripe: "#f0f2ec",
			muted: "#68756d"
		},
		blue: {
			paper: "#f8fcff",
			header: "#c9e5f6",
			title: "#234e70",
			ink: "#234e70",
			accent: "#7aafcc",
			stripe: "#eaf4fb",
			muted: "#607c90"
		},
		pink: {
			paper: "#fffafb",
			header: "#f3cfdb",
			title: "#783d55",
			ink: "#69384c",
			accent: "#c58c9f",
			stripe: "#faedf2",
			muted: "#886774"
		},
		orange: {
			paper: "#fffbf5",
			header: "#f5d3af",
			title: "#784520",
			ink: "#683e25",
			accent: "#c58b50",
			stripe: "#fbefdf",
			muted: "#877055"
		},
		purple: {
			paper: "#fcfaff",
			header: "#ded2ee",
			title: "#543970",
			ink: "#513b68",
			accent: "#a58cbe",
			stripe: "#f1ebf8",
			muted: "#7c6d90"
		},
		red: {
			paper: "#fffaf7",
			header: "#923f4b",
			title: "#fff4e8",
			ink: "#71343e",
			accent: "#d6b17f",
			stripe: "#f7eaea",
			muted: "#8c686b"
		},
		black: {
			paper: "#fcfbf8",
			header: "#282a2e",
			title: "#f7efdf",
			ink: "#303237",
			accent: "#bba47a",
			stripe: "#efeeeb",
			muted: "#72716d"
		},
		yellow: {
			paper: "#fffdf5",
			header: "#f2dfa0",
			title: "#625025",
			ink: "#5f4e27",
			accent: "#b7a064",
			stripe: "#f8f1d8",
			muted: "#837651"
		}
	};
	function readRecords$1(key) {
		try {
			const value = JSON.parse(localStorage.getItem(key) || "[]");
			return Array.isArray(value) ? value : [];
		} catch (_unused) {
			return [];
		}
	}
	function loadLatestResults() {
		return buildCertificateResults(Object.fromEntries(Object.entries(STORAGE_KEYS).map(([name, key]) => [name, readRecords$1(key)])));
	}
	function loadImage(dataUrl) {
		return new Promise((resolve, reject) => {
			const image = new Image();
			image.onload = () => resolve(image);
			image.onerror = () => reject(/* @__PURE__ */ new Error("图片读取失败"));
			image.src = dataUrl;
		});
	}
	function roundedRect(context, x, y, width, height, radius) {
		const r = Math.min(radius, width / 2, height / 2);
		context.beginPath();
		context.moveTo(x + r, y);
		context.arcTo(x + width, y, x + width, y + height, r);
		context.arcTo(x + width, y + height, x, y + height, r);
		context.arcTo(x, y + height, x, y, r);
		context.arcTo(x, y, x + width, y, r);
		context.closePath();
	}
	function drawCoverImage(context, image, x, y, width, height) {
		const scale = Math.max(width / image.naturalWidth, height / image.naturalHeight);
		const sourceWidth = width / scale;
		const sourceHeight = height / scale;
		const sourceX = (image.naturalWidth - sourceWidth) / 2;
		const sourceY = (image.naturalHeight - sourceHeight) / 2;
		context.drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, x, y, width, height);
	}
	function fitText(context, text, maxWidth) {
		if (context.measureText(text).width <= maxWidth) return text;
		let value = text;
		while (value.length > 1 && context.measureText(`${value}…`).width > maxWidth) value = value.slice(0, -1);
		return `${value}…`;
	}
	function addCalendarMonths(date, months) {
		const result = new Date(date);
		const day = result.getDate();
		result.setDate(1);
		result.setMonth(result.getMonth() + months);
		const lastDay = new Date(result.getFullYear(), result.getMonth() + 1, 0).getDate();
		result.setDate(Math.min(day, lastDay));
		return result;
	}
	function drawCertificateSeal(context, x, y) {
		context.save();
		context.translate(x, y);
		context.rotate(-.12);
		context.globalAlpha = .76;
		context.strokeStyle = "#c92f3d";
		context.fillStyle = "#c92f3d";
		context.lineWidth = 5;
		context.beginPath();
		context.arc(0, 0, 112, 0, Math.PI * 2);
		context.stroke();
		context.lineWidth = 2;
		context.beginPath();
		context.arc(0, 0, 103, 0, Math.PI * 2);
		context.stroke();
		context.textAlign = "center";
		context.textBaseline = "middle";
		context.font = "700 25px system-ui, \"Microsoft YaHei\", sans-serif";
		[..."慢手耳鼻喉测试"].forEach((character, index, characters) => {
			const angle = -Math.PI / 2 + (index - (characters.length - 1) / 2) * .43;
			context.save();
			context.translate(Math.cos(angle) * 83, Math.sin(angle) * 83);
			context.rotate(angle + Math.PI / 2);
			context.fillText(character, 0, 0);
			context.restore();
		});
		context.beginPath();
		context.ellipse(-19, -13, 12, 35, -.2, 0, Math.PI * 2);
		context.ellipse(19, -13, 12, 35, .2, 0, Math.PI * 2);
		context.fill();
		context.beginPath();
		context.ellipse(0, 27, 39, 32, 0, 0, Math.PI * 2);
		context.fill();
		context.fillStyle = "#fffdf8";
		for (const eyeX of [-13, 13]) {
			context.beginPath();
			context.arc(eyeX, 24, 3.5, 0, Math.PI * 2);
			context.fill();
		}
		context.beginPath();
		context.moveTo(-4, 36);
		context.lineTo(4, 36);
		context.lineTo(0, 41);
		context.fill();
		context.restore();
	}
	function setupCertificate({ showToast }) {
		const typeInputs = [...document.querySelectorAll("input[name=\"certificate-type\"]")];
		const avatarInput = document.querySelector("#certificate-avatar-input");
		const avatarPreview = document.querySelector("#certificate-avatar-preview");
		const avatarPlaceholder = document.querySelector("#certificate-avatar-placeholder");
		const nameInput = document.querySelector("#certificate-name");
		const preview = document.querySelector("#certificate-data-preview");
		const manualPanel = document.querySelector("#certificate-manual-panel");
		const manualInputs = [...manualPanel.querySelectorAll("input[data-result]")];
		const generateButton = document.querySelector("#certificate-generate");
		const outputSection = document.querySelector("#certificate-output-section");
		const outputImage = document.querySelector("#certificate-output");
		const downloadLink = document.querySelector("#certificate-download");
		let avatarImage = null;
		let avatarData = "";
		let avatarRevision = 0;
		let latestResults = loadLatestResults();
		function saveProfile() {
			try {
				localStorage.setItem("lita-certificate-profile", JSON.stringify({
					nickname: nameInput.value,
					avatar: avatarData
				}));
			} catch (_unused2) {
				showToast("浏览器存储空间不足，头像和称呼暂时无法缓存");
			}
		}
		function showAvatar(image, data) {
			avatarImage = image;
			avatarData = data;
			avatarPreview.src = data;
			avatarPreview.hidden = false;
			avatarPlaceholder.hidden = true;
		}
		nameInput.addEventListener("change", saveProfile);
		nameInput.addEventListener("input", saveProfile);
		try {
			const profile = JSON.parse(localStorage.getItem("lita-certificate-profile") || "{}");
			if (typeof profile.nickname === "string") nameInput.value = profile.nickname.slice(0, 20);
			if (typeof profile.avatar === "string" && profile.avatar.startsWith("data:image/")) {
				avatarData = profile.avatar;
				const revision = avatarRevision;
				loadImage(profile.avatar).then((image) => {
					if (revision === avatarRevision) showAvatar(image, profile.avatar);
				}).catch(() => {});
			}
		} catch (_unused3) {}
		bindReportSave(downloadLink, outputImage, showToast);
		function selectedType() {
			var _typeInputs$find$valu, _typeInputs$find;
			return (_typeInputs$find$valu = (_typeInputs$find = typeInputs.find((input) => input.checked)) === null || _typeInputs$find === void 0 ? void 0 : _typeInputs$find.value) !== null && _typeInputs$find$valu !== void 0 ? _typeInputs$find$valu : "report";
		}
		function renderResults() {
			preview.replaceChildren();
			for (const [key, label] of Object.entries(RESULT_LABELS)) {
				const row = document.createElement("div");
				const name = document.createElement("span");
				const value = document.createElement("strong");
				name.textContent = label;
				value.textContent = latestResults[key];
				row.append(name, value);
				preview.append(row);
			}
		}
		function updateType() {
			const forged = selectedType() === "forged";
			manualPanel.hidden = !forged;
			preview.hidden = forged;
		}
		function refresh() {
			latestResults = loadLatestResults();
			renderResults();
			manualInputs.forEach((input) => {
				input.value = latestResults[input.dataset.result];
			});
			updateType();
		}
		avatarInput.addEventListener("change", async () => {
			const [file] = avatarInput.files;
			if (!file) return;
			const revision = ++avatarRevision;
			if (!file.type.startsWith("image/")) {
				showToast("请选择图片文件");
				avatarInput.value = "";
				return;
			}
			if (file.size > 12582912) {
				showToast("图片不能超过 12MB");
				avatarInput.value = "";
				return;
			}
			try {
				const original = await loadImage(await new Promise((resolve, reject) => {
					const reader = new FileReader();
					reader.onload = () => resolve(reader.result);
					reader.onerror = () => reject(reader.error);
					reader.readAsDataURL(file);
				}));
				if (revision !== avatarRevision) return;
				const thumbnail = document.createElement("canvas");
				thumbnail.width = thumbnail.height = 512;
				const thumbnailContext = thumbnail.getContext("2d");
				thumbnailContext.fillStyle = "#ffffff";
				thumbnailContext.fillRect(0, 0, 512, 512);
				drawCoverImage(thumbnailContext, original, 0, 0, 512, 512);
				const compressed = thumbnail.toDataURL("image/jpeg", .88);
				const prepared = await loadImage(compressed);
				if (revision !== avatarRevision) return;
				showAvatar(prepared, compressed);
				saveProfile();
			} catch (_unused4) {
				showToast("头像读取失败，请重新选择");
			}
		});
		typeInputs.forEach((input) => input.addEventListener("change", updateType));
		generateButton.addEventListener("click", () => {
			var _CERTIFICATE_THEMES$d;
			const nickname = nameInput.value.trim();
			if (!avatarImage) {
				showToast("请先选择头像");
				return;
			}
			if (!nickname) {
				showToast("请输入你的称呼");
				nameInput.focus();
				return;
			}
			const type = selectedType();
			const theme = (_CERTIFICATE_THEMES$d = CERTIFICATE_THEMES[document.querySelector("#certificate-color").value]) !== null && _CERTIFICATE_THEMES$d !== void 0 ? _CERTIFICATE_THEMES$d : CERTIFICATE_THEMES.pink;
			const results = type === "forged" ? Object.fromEntries(manualInputs.map((input) => [input.dataset.result, input.value.trim() || "未测试"])) : loadLatestResults();
			const canvas = document.createElement("canvas");
			canvas.width = 1080;
			canvas.height = 1080;
			const context = canvas.getContext("2d");
			context.fillStyle = theme.paper;
			context.fillRect(0, 0, 1080, 1080);
			context.fillStyle = theme.header;
			context.fillRect(0, 0, 1080, 174);
			context.fillStyle = theme.accent;
			context.fillRect(0, 174, 1080, 6);
			context.fillStyle = theme.title;
			context.font = "700 64px system-ui, \"Microsoft YaHei\", sans-serif";
			context.textAlign = "left";
			context.fillText(CERTIFICATE_TITLES[type], 64, 112);
			context.save();
			roundedRect(context, 64, 222, 260, 260, 12);
			context.clip();
			drawCoverImage(context, avatarImage, 64, 222, 260, 260);
			context.restore();
			context.fillStyle = theme.ink;
			let nameSize = 62;
			do {
				context.font = `700 ${nameSize}px system-ui, "Microsoft YaHei", sans-serif`;
				if (context.measureText(nickname).width <= 638 || nameSize <= 32) break;
				nameSize -= 2;
			} while (true);
			context.fillText(fitText(context, nickname, 638), 376, 298);
			Object.entries(RESULT_LABELS).forEach(([key, label], index) => {
				const top = 526 + index * 86;
				context.fillStyle = index % 2 === 0 ? theme.stripe : theme.paper;
				context.fillRect(0, top, 1080, 86);
				context.textAlign = "left";
				context.fillStyle = theme.muted;
				context.font = "500 30px system-ui, \"Microsoft YaHei\", sans-serif";
				context.fillText(label, 64, top + 54);
				context.fillStyle = results[key] === "未测试" ? theme.muted : theme.ink;
				context.font = "600 34px system-ui, \"Microsoft YaHei\", sans-serif";
				context.fillText(fitText(context, results[key], 714), 302, top + 54);
			});
			const dateFormatter = new Intl.DateTimeFormat("zh-CN", {
				year: "numeric",
				month: "2-digit",
				day: "2-digit"
			});
			const validFrom = /* @__PURE__ */ new Date();
			const validUntil = addCalendarMonths(validFrom, 6);
			context.textAlign = "left";
			context.fillStyle = theme.muted;
			context.font = "500 28px system-ui, \"Microsoft YaHei\", sans-serif";
			context.fillText(`有效期 ${dateFormatter.format(validFrom)} ~ ${dateFormatter.format(validUntil)}`, 64, 994);
			drawCertificateSeal(context, 918, 951);
			const dataUrl = canvas.toDataURL("image/png");
			outputImage.src = dataUrl;
			outputSection.hidden = false;
			outputSection.scrollIntoView({
				behavior: "smooth",
				block: "start"
			});
		});
		refresh();
		return { refresh };
	}
	//#endregion
	//#region index.js
	var menuItems = document.querySelectorAll(".menu-item");
	var toast = document.querySelector(".toast");
	var homeHeader = document.querySelector("#home-header");
	var homeView = document.querySelector("#home-view");
	var homeAuthorCard = document.querySelector("#home-author-card");
	var hearingView = document.querySelector("#hearing-view");
	var slider = document.querySelector("#frequency-slider");
	var frequencyValue = document.querySelector("#frequency-value");
	var decreaseButton = document.querySelector("#decrease-frequency");
	var increaseButton = document.querySelector("#increase-frequency");
	var playButton = document.querySelector("#play-button");
	var history = document.querySelector("#history");
	var reportDialog = document.querySelector("#report-dialog");
	var reportClose = document.querySelector("#report-close");
	var professionalView = document.querySelector("#professional-view");
	var testIntro = document.querySelector("#test-intro");
	var testSession = document.querySelector("#test-session");
	var testResult = document.querySelector("#test-result");
	var lowPhase = document.querySelector("#low-phase");
	var highPhase = document.querySelector("#high-phase");
	var testPhaseLabel = document.querySelector("#test-phase-label");
	var testPrompt = document.querySelector("#test-prompt");
	var testCounter = document.querySelector("#test-counter");
	var testFeedback = document.querySelector("#test-feedback");
	var nextTrialButton = document.querySelector("#next-trial");
	var testAnswers = document.querySelector("#test-answers");
	var resultHeading = document.querySelector("#result-heading");
	var resultValues = document.querySelector("#result-values");
	var voiceView = document.querySelector("#voice-view");
	var voiceProfessionalView = document.querySelector("#voice-professional-view");
	var psychologyView = document.querySelector("#psychology-view");
	var psychologyTestView = document.querySelector("#psychology-test-view");
	var visionView = document.querySelector("#vision-view");
	var visionTestView = document.querySelector("#vision-test-view");
	var certificateView = document.querySelector("#certificate-view");
	var voiceDeviceButton = document.querySelector("#voice-device-button");
	var voiceDeviceStatus = document.querySelector("#voice-device-status");
	var voiceDeviceDetail = document.querySelector("#voice-device-detail");
	var voiceIntro = document.querySelector("#voice-intro");
	var voiceSession = document.querySelector("#voice-session");
	var voiceStart = document.querySelector("#voice-start");
	var voiceError = document.querySelector("#voice-error");
	var voiceRecording = document.querySelector("#voice-recording");
	var voiceLiveNote = document.querySelector("#voice-live-note");
	var voiceLiveHz = document.querySelector("#voice-live-hz");
	var voiceMinimum = document.querySelector("#voice-minimum");
	var voiceMaximum = document.querySelector("#voice-maximum");
	var voiceMinimumNote = document.querySelector("#voice-minimum-note");
	var voiceMaximumNote = document.querySelector("#voice-maximum-note");
	var voiceHistory = document.querySelector("#voice-history");
	var voiceReportDialog = document.querySelector("#voice-report-dialog");
	var psychologyReportDialog = document.querySelector("#psychology-report-dialog");
	var visionReportDialog = document.querySelector("#vision-report-dialog");
	var voiceTestChart = document.querySelector("#voice-test-chart");
	var MIN_FREQUENCY = 10;
	var MAX_FREQUENCY = 25e3;
	var STORAGE_KEY = "lita-hearing-records";
	var VOICE_STORAGE_KEY = "lita-voice-records";
	var AudioContextConstructor = window.AudioContext || window.webkitAudioContext;
	var PROFESSIONAL_SILENT_GAIN = 1e-5;
	var formatNumber = new Intl.NumberFormat("zh-CN");
	var formatDate = new Intl.DateTimeFormat("zh-CN", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	});
	var frequency = 1e3;
	var audioContext;
	var oscillator;
	var gain;
	var professionalOscillator;
	var professionalGain;
	var toastTimer;
	var startingSound = false;
	var heldPointerId = null;
	var holdDelay;
	var holdInterval;
	var ignorePointerClick = false;
	var professionalTest;
	var trialStarting = false;
	var trialActive = false;
	var trialSignal = false;
	var trialFeedback = null;
	var testGeneration = 0;
	var voiceGeneration = 0;
	var voiceMode = null;
	var voiceStream;
	var voiceContext;
	var voiceFrame;
	var voiceRange = createPitchRange();
	var voiceStartedAt;
	var VOICE_CHART_DURATION = 8e3;
	var VOICE_CHART_MIN = 65;
	var VOICE_CHART_MAX = VOICE_MAX_PITCH;
	var VOICE_MIN_RMS = .003;
	var VOICE_MIN_CLARITY = .5;
	var VOICE_SAMPLE_INTERVAL = 45;
	var voiceCharts = { test: createVoiceChartState(voiceTestChart) };
	function createVoiceChartState(canvas) {
		return {
			canvas,
			points: [],
			smoothedHz: null,
			lastVoicedAt: 0
		};
	}
	function resetVoiceChart(mode) {
		const chart = voiceCharts[mode];
		if (!chart) return;
		chart.points = [];
		chart.smoothedHz = null;
		chart.lastVoicedAt = 0;
		drawVoiceChart(chart, performance.now());
	}
	function addVoiceChartPoint(mode, now, hz) {
		const chart = voiceCharts[mode];
		if (!chart) return;
		let displayHz = null;
		if (hz !== null) {
			chart.smoothedHz = chart.smoothedHz !== null && now - chart.lastVoicedAt < 400 ? chart.smoothedHz * .68 + hz * .32 : hz;
			chart.lastVoicedAt = now;
			displayHz = chart.smoothedHz;
		} else if (now - chart.lastVoicedAt >= 400) chart.smoothedHz = null;
		chart.points.push({
			time: now,
			hz: displayHz
		});
		const cutoff = now - VOICE_CHART_DURATION;
		while (chart.points.length && chart.points[0].time < cutoff) chart.points.shift();
		drawVoiceChart(chart, now);
	}
	function drawVoiceChart(chart, now) {
		const canvas = chart.canvas;
		const width = canvas.clientWidth;
		const height = canvas.clientHeight;
		if (!width || !height) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const pixelWidth = Math.round(width * dpr);
		const pixelHeight = Math.round(height * dpr);
		if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
			canvas.width = pixelWidth;
			canvas.height = pixelHeight;
		}
		const context = canvas.getContext("2d");
		context.setTransform(dpr, 0, 0, dpr, 0, 0);
		context.clearRect(0, 0, width, height);
		const left = 38;
		const right = 10;
		const top = 12;
		const bottom = 22;
		const plotWidth = width - left - right;
		const plotHeight = height - top - bottom;
		const logMin = Math.log(VOICE_CHART_MIN);
		const logMax = Math.log(VOICE_CHART_MAX);
		const yForHz = (hz) => top + (logMax - Math.log(hz)) / (logMax - logMin) * plotHeight;
		context.font = "10px -apple-system, BlinkMacSystemFont, sans-serif";
		context.textAlign = "right";
		context.textBaseline = "middle";
		[
			100,
			200,
			400,
			800,
			1600
		].forEach((hz) => {
			const y = yForHz(hz);
			context.fillStyle = "#92989a";
			context.fillText(String(hz), 31, y);
			context.beginPath();
			context.moveTo(left, y);
			context.lineTo(width - right, y);
			context.strokeStyle = "#e2e8e5";
			context.lineWidth = 1;
			context.stroke();
		});
		context.textAlign = "left";
		context.textBaseline = "alphabetic";
		context.fillStyle = "#92989a";
		context.fillText("Hz", 8, 12);
		context.fillText("8 秒前", left, height - 6);
		context.textAlign = "right";
		context.fillText("现在", width - right, height - 6);
		const cutoff = now - VOICE_CHART_DURATION;
		if (!chart.points.filter((point) => point.hz !== null).length) {
			context.fillStyle = "#9a9fa1";
			context.font = "13px -apple-system, BlinkMacSystemFont, sans-serif";
			context.textAlign = "center";
			context.textBaseline = "middle";
			context.fillText("等待检测到稳定音调", left + plotWidth / 2, top + plotHeight / 2);
			return;
		}
		context.save();
		context.beginPath();
		context.rect(left, top, plotWidth, plotHeight);
		context.clip();
		context.beginPath();
		let drawing = false;
		let previousTime = 0;
		chart.points.forEach((point) => {
			if (point.hz === null || point.time - previousTime > 220) {
				drawing = false;
				if (point.hz === null) return;
			}
			const x = left + (point.time - cutoff) / VOICE_CHART_DURATION * plotWidth;
			const y = yForHz(Math.min(VOICE_CHART_MAX, Math.max(VOICE_CHART_MIN, point.hz)));
			if (drawing) context.lineTo(x, y);
			else context.moveTo(x, y);
			drawing = true;
			previousTime = point.time;
		});
		context.strokeStyle = "#31836c";
		context.lineWidth = 2.25;
		context.lineCap = "round";
		context.lineJoin = "round";
		context.stroke();
		context.restore();
	}
	function drawVisibleVoiceCharts() {
		const now = performance.now();
		Object.values(voiceCharts).forEach((chart) => drawVoiceChart(chart, now));
	}
	function stopStepping() {
		window.clearTimeout(holdDelay);
		window.clearInterval(holdInterval);
		heldPointerId = null;
	}
	function setupStepButton(button, direction) {
		button.addEventListener("pointerdown", (event) => {
			if (event.pointerType === "mouse" && event.button !== 0 || heldPointerId !== null || button.disabled) return;
			ignorePointerClick = true;
			heldPointerId = event.pointerId;
			setFrequency(frequency + direction);
			holdDelay = window.setTimeout(() => {
				holdInterval = window.setInterval(() => {
					setFrequency(frequency + direction);
					if (button.disabled) stopStepping();
				}, 25);
			}, 400);
		});
		button.addEventListener("click", (event) => {
			if (ignorePointerClick && event.detail !== 0) {
				ignorePointerClick = false;
				return;
			}
			ignorePointerClick = false;
			setFrequency(frequency + direction);
		});
		button.addEventListener("contextmenu", (event) => event.preventDefault());
	}
	function showToast(message) {
		toast.textContent = message;
		toast.classList.add("is-visible");
		window.clearTimeout(toastTimer);
		toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 1800);
	}
	var psychologyController = setupPsychologyTest({
		formatDate,
		showToast
	});
	var visionController = setupVisionTest({
		formatDate,
		showToast
	});
	var certificateController = setupCertificate({ showToast });
	function setFrequency(hz) {
		frequency = Math.min(MAX_FREQUENCY, Math.max(MIN_FREQUENCY, Math.round(hz)));
		frequencyValue.value = formatNumber.format(frequency);
		slider.value = String(frequency);
		slider.setAttribute("aria-valuetext", `${frequency} Hz`);
		decreaseButton.disabled = frequency === MIN_FREQUENCY;
		increaseButton.disabled = frequency === MAX_FREQUENCY;
		if (oscillator) oscillator.frequency.setTargetAtTime(frequency, audioContext.currentTime, .015);
	}
	function stopSound() {
		if (!oscillator) return;
		const activeOscillator = oscillator;
		const activeGain = gain;
		oscillator = null;
		scheduleSmoothGain(activeGain.gain, 0, .16);
		activeOscillator.addEventListener("ended", () => {
			activeOscillator.disconnect();
			activeGain.disconnect();
		}, { once: true });
		activeOscillator.stop(audioContext.currentTime + .18);
		playButton.textContent = "播放声音";
		playButton.classList.remove("is-playing");
		playButton.setAttribute("aria-pressed", "false");
	}
	function ensurePlaybackAudioContext() {
		if (!AudioContextConstructor) throw new Error("Web Audio API unavailable");
		if (!audioContext || audioContext.state === "closed") audioContext = new AudioContextConstructor();
		return audioContext;
	}
	async function resumeAudioContext(context) {
		if (context.state === "running") return;
		const resumeResult = context.resume();
		if (resumeResult && typeof resumeResult.then === "function") await resumeResult;
	}
	function scheduleSmoothGain(parameter, target, duration) {
		const now = audioContext.currentTime;
		const start = Math.max(0, parameter.value);
		const curve = /* @__PURE__ */ new Float32Array(96);
		for (let index = 0; index < curve.length; index += 1) {
			const progress = index / (curve.length - 1);
			const eased = .5 - .5 * Math.cos(Math.PI * progress);
			curve[index] = start + (target - start) * eased;
		}
		parameter.cancelScheduledValues(now);
		parameter.setValueCurveAtTime(curve, now, duration);
	}
	function professionalOutputGain(hz) {
		if (hz < 80) return .12;
		if (hz < 200) return .12 + (hz - 80) / 120 * .16;
		if (hz > 18e3) return .2;
		if (hz > 14e3) return .28;
		return .4;
	}
	function startTone(hz) {
		const now = audioContext.currentTime;
		gain = audioContext.createGain();
		gain.gain.setValueAtTime(0, now);
		gain.connect(audioContext.destination);
		oscillator = audioContext.createOscillator();
		oscillator.type = "sine";
		oscillator.frequency.setValueAtTime(hz, now);
		oscillator.connect(gain);
		oscillator.start(now);
		scheduleSmoothGain(gain.gain, .5, .32);
	}
	function ensureProfessionalToneEngine(context) {
		if (professionalOscillator && professionalGain) return false;
		const now = context.currentTime;
		professionalGain = context.createGain();
		professionalGain.gain.setValueAtTime(PROFESSIONAL_SILENT_GAIN, now);
		professionalGain.connect(context.destination);
		professionalOscillator = context.createOscillator();
		professionalOscillator.type = "sine";
		professionalOscillator.frequency.setValueAtTime(1e3, now);
		professionalOscillator.connect(professionalGain);
		professionalOscillator.start(now);
		return true;
	}
	function setProfessionalTone(hz, audible) {
		if (!professionalOscillator || !professionalGain || !audioContext) return;
		professionalOscillator.frequency.setValueAtTime(hz, audioContext.currentTime);
		scheduleSmoothGain(professionalGain.gain, audible ? professionalOutputGain(hz) : PROFESSIONAL_SILENT_GAIN, audible ? .8 : .24);
	}
	function silenceProfessionalTone() {
		if (!professionalGain || !audioContext) return;
		scheduleSmoothGain(professionalGain.gain, PROFESSIONAL_SILENT_GAIN, .28);
	}
	function destroyProfessionalToneEngine() {
		if (!professionalOscillator || !professionalGain || !audioContext) {
			professionalOscillator = void 0;
			professionalGain = void 0;
			return;
		}
		const activeOscillator = professionalOscillator;
		const activeGain = professionalGain;
		const now = audioContext.currentTime;
		professionalOscillator = void 0;
		professionalGain = void 0;
		scheduleSmoothGain(activeGain.gain, 0, .18);
		activeOscillator.addEventListener("ended", () => {
			activeOscillator.disconnect();
			activeGain.disconnect();
		}, { once: true });
		activeOscillator.stop(now + .2);
	}
	async function toggleSound() {
		if (startingSound) return;
		if (oscillator) {
			stopSound();
			return;
		}
		startingSound = true;
		try {
			const context = ensurePlaybackAudioContext();
			startTone(frequency);
			playButton.textContent = "停止播放";
			playButton.classList.add("is-playing");
			playButton.setAttribute("aria-pressed", "true");
			await resumeAudioContext(context);
			if (context.state !== "running") throw new Error(`AudioContext state: ${context.state}`);
			if (hearingView.hidden) stopSound();
			console.debug("[听觉赫兹测试] 音频已启动", {
				state: context.state,
				sampleRate: context.sampleRate,
				frequency
			});
		} catch (error) {
			stopSound();
			console.error("[听觉赫兹测试] 无法启动音频", error);
			showToast("无法播放声音，请检查媒体音量后重试");
		} finally {
			startingSound = false;
		}
	}
	function resetProfessionalTest() {
		testGeneration += 1;
		professionalTest = null;
		trialStarting = false;
		trialActive = false;
		trialFeedback = null;
		stopSound();
		destroyProfessionalToneEngine();
	}
	function showCurrentView() {
		if (reportDialog.open) reportDialog.close();
		if (voiceReportDialog.open) voiceReportDialog.close();
		if (psychologyReportDialog.open) psychologyReportDialog.close();
		if (visionReportDialog.open) visionReportDialog.close();
		const isHearing = location.hash === "#hearing";
		const isProfessional = location.hash === "#professional";
		const isVoice = location.hash === "#voice";
		const isVoiceProfessional = location.hash === "#voice-professional";
		const isPsychology = location.hash === "#psychology";
		const isPsychologyTest = location.hash === "#psychology-test";
		const isVision = location.hash === "#vision";
		const isVisionTest = location.hash === "#vision-test";
		const isCertificate = location.hash === "#certificate";
		homeHeader.hidden = isHearing || isProfessional || isVoice || isVoiceProfessional || isPsychology || isPsychologyTest || isVision || isVisionTest || isCertificate;
		homeView.hidden = homeHeader.hidden;
		if (homeAuthorCard) homeAuthorCard.hidden = homeHeader.hidden;
		hearingView.hidden = !isHearing;
		professionalView.hidden = !isProfessional;
		voiceView.hidden = !isVoice;
		voiceProfessionalView.hidden = !isVoiceProfessional;
		psychologyView.hidden = !isPsychology;
		psychologyTestView.hidden = !isPsychologyTest;
		visionView.hidden = !isVision;
		visionTestView.hidden = !isVisionTest;
		certificateView.hidden = !isCertificate;
		document.title = isCertificate ? "证书办理 - 慢手耳鼻喉测试" : isVisionTest ? "视觉测试中 - 机能测试" : isVision ? "视觉测试 - 机能测试" : isPsychologyTest ? "心理年龄测试中 - 机能测试" : isPsychology ? "心理年龄测试 - 机能测试" : isVoiceProfessional ? "发声音调专业测试 - 机能测试" : isVoice ? "发声音调测试 - 机能测试" : isProfessional ? "专业测试 - 机能测试" : isHearing ? "听觉赫兹测试 - 机能测试" : "机能测试";
		if (!isHearing) {
			stopStepping();
			stopSound();
		}
		if (!isProfessional) resetProfessionalTest();
		else renderProfessionalState();
		if (voiceMode && (voiceMode === "device" && !isVoice || voiceMode === "test" && !isVoiceProfessional)) {
			stopVoiceCapture();
			if (!isVoiceProfessional) resetVoiceSession();
		}
		if (isPsychologyTest) psychologyController.ensureStarted();
		else psychologyController.leaveTest();
		if (isPsychology) psychologyController.renderHistory();
		if (isVisionTest) visionController.ensureStarted();
		else visionController.leaveTest();
		if (isVision) visionController.renderHistory();
		if (isCertificate) certificateController.refresh();
		window.requestAnimationFrame(drawVisibleVoiceCharts);
	}
	function stopVoiceCapture() {
		voiceGeneration += 1;
		window.cancelAnimationFrame(voiceFrame);
		voiceFrame = void 0;
		voiceStream === null || voiceStream === void 0 || voiceStream.getTracks().forEach((track) => track.stop());
		voiceStream = void 0;
		if (voiceContext) {
			voiceContext.close().catch(() => {});
			voiceContext = void 0;
		}
		voiceMode = null;
		voiceDeviceButton.disabled = false;
		voiceDeviceButton.textContent = "检测麦克风";
	}
	function resetVoiceSession() {
		voiceIntro.hidden = false;
		voiceSession.hidden = true;
		voiceStart.disabled = false;
		voiceStart.textContent = "开始测试";
		voiceError.hidden = true;
		voiceRecording.textContent = "";
		const dot = document.createElement("span");
		dot.className = "voice-recording-dot";
		voiceRecording.append(dot, "正在录音，可以尽情地叫");
		voiceLiveNote.textContent = "--";
		voiceLiveHz.textContent = "等待声音";
		voiceMinimum.textContent = "--";
		voiceMaximum.textContent = "--";
		voiceMinimumNote.textContent = "";
		voiceMaximumNote.textContent = "";
		voiceRange = createPitchRange();
		voiceStartedAt = void 0;
	}
	function voiceErrorMessage(error) {
		if (!window.isSecureContext) return "麦克风需要安全连接，请使用 HTTPS 或在本机通过 localhost 打开";
		if ((error === null || error === void 0 ? void 0 : error.name) === "NotAllowedError" || (error === null || error === void 0 ? void 0 : error.name) === "PermissionDeniedError") return "未获得麦克风权限，请在浏览器设置中允许访问";
		if ((error === null || error === void 0 ? void 0 : error.name) === "NotFoundError" || (error === null || error === void 0 ? void 0 : error.name) === "DevicesNotFoundError") return "没有找到可用的麦克风";
		return "无法启动麦克风，请检查设备或浏览器设置";
	}
	function showVoiceRange() {
		for (const [hz, value, note] of [[
			voiceRange.minimum,
			voiceMinimum,
			voiceMinimumNote
		], [
			voiceRange.maximum,
			voiceMaximum,
			voiceMaximumNote
		]]) {
			value.textContent = hz === null ? "--" : `${Math.round(hz)} Hz`;
			note.textContent = hz === null ? "" : frequencyToNote(hz);
		}
	}
	async function startVoiceCapture(mode) {
		stopVoiceCapture();
		resetVoiceChart(mode);
		const generation = voiceGeneration;
		voiceMode = mode;
		const isTest = mode === "test";
		if (isTest) {
			voiceError.hidden = true;
			voiceStart.disabled = true;
			voiceStart.textContent = "连接麦克风...";
		} else {
			voiceDeviceButton.disabled = true;
			voiceDeviceStatus.textContent = "正在连接麦克风";
			voiceDeviceDetail.textContent = "请允许浏览器使用麦克风";
		}
		try {
			var _navigator$mediaDevic, _stream$getAudioTrack;
			if (!((_navigator$mediaDevic = navigator.mediaDevices) === null || _navigator$mediaDevic === void 0 ? void 0 : _navigator$mediaDevic.getUserMedia) || !AudioContextConstructor) throw new Error("microphone unavailable");
			const stream = await navigator.mediaDevices.getUserMedia({ audio: {
				channelCount: 1,
				echoCancellation: false,
				noiseSuppression: false,
				autoGainControl: true
			} });
			if (generation !== voiceGeneration || (isTest ? voiceProfessionalView.hidden : voiceView.hidden)) {
				stream.getTracks().forEach((track) => track.stop());
				return;
			}
			voiceStream = stream;
			voiceContext = new AudioContextConstructor();
			await voiceContext.resume();
			if (generation !== voiceGeneration) return;
			const source = voiceContext.createMediaStreamSource(stream);
			const analyser = voiceContext.createAnalyser();
			analyser.fftSize = 4096;
			source.connect(analyser);
			const buffer = new Float32Array(analyser.fftSize);
			const detector = PitchDetector.forFloat32Array(buffer.length);
			if (isTest) {
				voiceRange = createPitchRange();
				voiceStartedAt = (/* @__PURE__ */ new Date()).toISOString();
				voiceIntro.hidden = true;
				voiceSession.hidden = false;
			} else {
				voiceDeviceButton.disabled = false;
				voiceDeviceButton.textContent = "停止检测";
				voiceDeviceStatus.textContent = "麦克风已连接";
				voiceDeviceDetail.textContent = "请说话或哼唱";
			}
			let lastSample = 0;
			let lastSound = 0;
			function sample(now) {
				if (generation !== voiceGeneration) return;
				voiceFrame = window.requestAnimationFrame(sample);
				if (now - lastSample < VOICE_SAMPLE_INTERVAL) return;
				lastSample = now;
				analyser.getFloatTimeDomainData(buffer);
				const [hz, clarity] = Math.sqrt(buffer.reduce((sum, value) => sum + value * value, 0) / buffer.length) >= VOICE_MIN_RMS ? detector.findPitch(buffer, voiceContext.sampleRate) : [0, 0];
				const hasStablePitch = clarity >= VOICE_MIN_CLARITY && hz >= 65 && hz <= 2200;
				addVoiceChartPoint(mode, now, hasStablePitch ? hz : null);
				if (hasStablePitch) {
					lastSound = now;
					if (isTest) {
						voiceLiveNote.textContent = frequencyToNote(hz);
						voiceLiveHz.textContent = `${Math.round(hz)} Hz`;
						if (trackPitch(voiceRange, hz)) showVoiceRange();
					} else {
						voiceDeviceStatus.textContent = "拾音正常";
						voiceDeviceDetail.textContent = `${Math.round(hz)} Hz · ${frequencyToNote(hz)}`;
					}
				} else {
					if (isTest) trackPitch(voiceRange, null);
					if (now - lastSound > 400) {
						if (isTest) {
							voiceLiveNote.textContent = "--";
							voiceLiveHz.textContent = "等待声音";
						} else {
							voiceDeviceStatus.textContent = "麦克风已连接";
							voiceDeviceDetail.textContent = "请说话或哼唱";
						}
					}
				}
			}
			voiceFrame = window.requestAnimationFrame(sample);
			(_stream$getAudioTrack = stream.getAudioTracks()[0]) === null || _stream$getAudioTrack === void 0 || _stream$getAudioTrack.addEventListener("ended", () => {
				if (generation !== voiceGeneration) return;
				stopVoiceCapture();
				if (isTest) {
					resetVoiceSession();
					showToast("麦克风已断开，测试未保存");
				} else {
					voiceDeviceStatus.textContent = "麦克风已断开";
					voiceDeviceDetail.textContent = "请重新检测";
				}
			});
		} catch (error) {
			if (generation !== voiceGeneration) return;
			stopVoiceCapture();
			if (isTest) {
				resetVoiceSession();
				voiceError.textContent = voiceErrorMessage(error);
				voiceError.hidden = false;
			} else {
				voiceDeviceStatus.textContent = "检测未完成";
				voiceDeviceDetail.textContent = voiceErrorMessage(error);
			}
			showToast(voiceErrorMessage(error));
		}
	}
	function readVoiceRecords() {
		try {
			const records = JSON.parse(localStorage.getItem(VOICE_STORAGE_KEY) || "[]");
			return Array.isArray(records) ? records : [];
		} catch (_unused) {
			return [];
		}
	}
	function voicePitchLabel(hz) {
		return hz == null ? "未测得" : `${Math.round(hz)} Hz · ${frequencyToNote(hz)}`;
	}
	function openVoiceReport(record) {
		document.querySelector("#voice-report-time").textContent = formatDate.format(new Date(record.time));
		document.querySelector("#voice-report-minimum").textContent = voicePitchLabel(record.minimum);
		document.querySelector("#voice-report-maximum").textContent = voicePitchLabel(record.maximum);
		document.querySelector("#voice-report-title-name").textContent = getVoiceTitle(record.maximum);
		voiceReportDialog.showModal();
	}
	function renderVoiceRecords() {
		voiceHistory.replaceChildren();
		const records = readVoiceRecords();
		if (!records.length) {
			const empty = document.createElement("p");
			empty.className = "history-empty";
			empty.textContent = "暂无记录";
			voiceHistory.append(empty);
			return;
		}
		const header = document.createElement("div");
		header.className = "history-header";
		for (const label of [
			"时间",
			"最低音调",
			"最高音调",
			"级别"
		]) {
			const cell = document.createElement("span");
			cell.textContent = label;
			header.append(cell);
		}
		voiceHistory.append(header);
		for (const record of records) {
			const row = document.createElement("button");
			row.type = "button";
			row.className = "history-row voice-history-row";
			row.setAttribute("aria-label", `查看 ${formatDate.format(new Date(record.time))} 的发声音调测试报告`);
			const time = document.createElement("time");
			time.dateTime = record.time;
			time.textContent = formatDate.format(new Date(record.time));
			row.append(time);
			for (const hz of [record.minimum, record.maximum]) {
				const cell = document.createElement("span");
				cell.textContent = hz == null ? "未测得" : `${Math.round(hz)} Hz`;
				if (hz != null) {
					const note = document.createElement("small");
					note.textContent = frequencyToNote(hz);
					cell.append(note);
				}
				row.append(cell);
			}
			const title = document.createElement("strong");
			title.className = `level-badge ${getLevelBadgeClass(getVoiceLevelRank(record.maximum))}`;
			title.textContent = getVoiceTitle(record.maximum);
			row.append(title);
			row.addEventListener("click", () => openVoiceReport(record));
			voiceHistory.append(row);
		}
	}
	function finishVoiceTest() {
		if (voiceMode !== "test" || !voiceStartedAt) return;
		if (voiceRange.minimum === null || voiceRange.maximum === null) {
			stopVoiceCapture();
			resetVoiceSession();
			showToast("未检测到稳定音调，未保存记录");
			return;
		}
		const record = {
			time: voiceStartedAt,
			minimum: voiceRange.minimum,
			maximum: voiceRange.maximum
		};
		stopVoiceCapture();
		resetVoiceSession();
		try {
			localStorage.setItem(VOICE_STORAGE_KEY, JSON.stringify([record, ...readVoiceRecords()]));
			renderVoiceRecords();
		} catch (_unused2) {
			showToast("记录保存失败，请检查浏览器存储空间");
		}
		openVoiceReport(record);
	}
	function readRecords() {
		try {
			const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
			return Array.isArray(records) ? records : [];
		} catch (_unused3) {
			return [];
		}
	}
	function renderRecords() {
		const records = readRecords();
		history.replaceChildren();
		if (!records.length) {
			const empty = document.createElement("p");
			empty.className = "history-empty";
			empty.textContent = "暂无记录";
			history.append(empty);
			return;
		}
		const header = document.createElement("div");
		header.className = "history-header";
		for (const label of [
			"时间",
			"最低音调",
			"最高音调",
			"级别"
		]) {
			const cell = document.createElement("span");
			cell.textContent = label;
			header.append(cell);
		}
		history.append(header);
		for (const record of records) {
			const row = document.createElement("button");
			row.type = "button";
			row.className = "history-row";
			row.setAttribute("aria-label", `查看 ${formatDate.format(new Date(record.time))} 的听觉测试报告`);
			const time = document.createElement("time");
			time.dateTime = record.time;
			time.textContent = formatDate.format(new Date(record.time));
			const minimum = document.createElement("span");
			minimum.textContent = record.minimum == null ? "未测得" : `${formatNumber.format(record.minimum)} Hz`;
			const maximum = document.createElement("span");
			maximum.textContent = record.maximum == null ? "未测得" : `${formatNumber.format(record.maximum)} Hz`;
			const title = document.createElement("strong");
			title.className = `level-badge ${getLevelBadgeClass(getHearingLevelRank(record.maximum))}`;
			title.textContent = getHearingTitle(record.maximum);
			row.append(time, minimum, maximum, title);
			row.addEventListener("click", () => {
				document.querySelector("#report-time").textContent = time.textContent;
				document.querySelector("#report-minimum").textContent = minimum.textContent;
				document.querySelector("#report-maximum").textContent = maximum.textContent;
				document.querySelector("#report-hearing-title").textContent = title.textContent;
				reportDialog.showModal();
			});
			history.append(row);
		}
	}
	function saveProfessionalResult() {
		const records = readRecords();
		records.unshift({
			time: (/* @__PURE__ */ new Date()).toISOString(),
			minimum: professionalTest.minimum,
			maximum: professionalTest.maximum
		});
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
			renderRecords();
		} catch (_unused4) {
			showToast("记录保存失败，请检查浏览器存储空间");
		}
	}
	function renderProfessionalState() {
		var _trialFeedback$phase;
		testIntro.hidden = Boolean(professionalTest);
		testSession.hidden = !professionalTest || professionalTest.phase === "done" && !trialFeedback;
		testResult.hidden = !professionalTest || professionalTest.phase !== "done" || Boolean(trialFeedback);
		if (!professionalTest) return;
		if (professionalTest.phase === "done" && !trialFeedback) {
			const { minimum, maximum } = professionalTest;
			resultHeading.textContent = minimum === null ? "未测得听觉范围" : "听觉范围";
			resultValues.replaceChildren();
			for (const [label, hz] of [["最低", minimum], ["最高", maximum]]) {
				const item = document.createElement("div");
				const caption = document.createElement("span");
				caption.textContent = label;
				const value = document.createElement("strong");
				value.textContent = hz === null ? "未测得" : `${formatNumber.format(hz)} Hz`;
				item.append(caption, value);
				resultValues.append(item);
			}
			return;
		}
		const isLow = ((_trialFeedback$phase = trialFeedback === null || trialFeedback === void 0 ? void 0 : trialFeedback.phase) !== null && _trialFeedback$phase !== void 0 ? _trialFeedback$phase : professionalTest.phase) === "low";
		lowPhase.classList.toggle("is-active", isLow);
		highPhase.classList.toggle("is-active", !isLow);
		testPhaseLabel.textContent = isLow ? "低音测试" : "高音测试";
		testPrompt.textContent = trialFeedback ? trialFeedback.correct ? "回答正确" : "回答错误" : trialStarting ? "准备中..." : trialActive ? "现在有声音吗？" : "准备好后继续";
		testPrompt.classList.toggle("is-correct", Boolean(trialFeedback === null || trialFeedback === void 0 ? void 0 : trialFeedback.correct));
		testPrompt.classList.toggle("is-incorrect", Boolean(trialFeedback && !trialFeedback.correct));
		testCounter.textContent = trialFeedback ? "本轮已结束" : `已判断 ${professionalTest.confirmed} 个频点 · 第 ${professionalTest.trials + 1} 次辨认`;
		testFeedback.hidden = !trialFeedback;
		if (trialFeedback) testFeedback.textContent = trialFeedback.signal ? `本轮播放了 ${formatNumber.format(trialFeedback.frequency)} Hz` : "本轮没有播放声音";
		nextTrialButton.hidden = trialStarting || trialActive;
		nextTrialButton.textContent = professionalTest.phase === "done" ? "查看测试结果" : "开始下一次辨认";
		testAnswers.hidden = !trialActive || Boolean(trialFeedback);
	}
	async function startProfessionalTrial() {
		if (!professionalTest || professionalTest.phase === "done" || trialActive || trialStarting || trialFeedback) return;
		trialStarting = true;
		renderProfessionalState();
		const generation = testGeneration;
		const signal = chooseProfessionalSignal(professionalTest);
		try {
			const context = ensurePlaybackAudioContext();
			const engineWasCreated = ensureProfessionalToneEngine(context);
			await resumeAudioContext(context);
			if (context.state !== "running") throw new Error(`AudioContext state: ${context.state}`);
			await new Promise((resolve) => window.setTimeout(resolve, engineWasCreated ? 360 : 100));
			if (generation !== testGeneration || professionalView.hidden) return;
			setProfessionalTone(professionalTest.frequency, signal);
			trialSignal = signal;
			trialActive = true;
		} catch (error) {
			destroyProfessionalToneEngine();
			console.error("[听觉专业测试] 无法启动音频", error);
			showToast("无法启动测试声音，请检查媒体音量");
		} finally {
			if (generation === testGeneration) {
				trialStarting = false;
				renderProfessionalState();
			}
		}
	}
	function startProfessionalTest() {
		stopSound();
		destroyProfessionalToneEngine();
		testGeneration += 1;
		professionalTest = createProfessionalTest();
		trialActive = false;
		trialFeedback = null;
		renderProfessionalState();
		startProfessionalTrial();
	}
	document.querySelector("#hearing-link").addEventListener("click", () => {
		location.hash = "hearing";
	});
	document.querySelector("#voice-link").addEventListener("click", () => {
		location.hash = "voice";
	});
	document.querySelector("#psychology-link").addEventListener("click", () => {
		location.hash = "psychology";
	});
	document.querySelector("#psychology-back").addEventListener("click", () => {
		location.hash = "";
	});
	document.querySelector("#psychology-test-back").addEventListener("click", () => {
		location.hash = "psychology";
	});
	document.querySelector("#vision-link").addEventListener("click", () => {
		location.hash = "vision";
	});
	document.querySelector("#vision-back").addEventListener("click", () => {
		location.hash = "";
	});
	document.querySelector("#vision-test-back").addEventListener("click", () => {
		location.hash = "vision";
	});
	document.querySelector("#certificate-link").addEventListener("click", () => {
		location.hash = "certificate";
	});
	document.querySelector("#certificate-back").addEventListener("click", () => {
		location.hash = "";
	});
	document.querySelector("#voice-back").addEventListener("click", () => {
		location.hash = "";
	});
	document.querySelector("#voice-professional-link").addEventListener("click", () => {
		location.hash = "voice-professional";
	});
	document.querySelector("#voice-professional-back").addEventListener("click", () => {
		location.hash = "voice";
	});
	voiceDeviceButton.addEventListener("click", () => {
		if (voiceMode === "device") {
			stopVoiceCapture();
			voiceDeviceStatus.textContent = "检测麦克风";
			voiceDeviceDetail.textContent = "说话或哼唱，确认麦克风能够拾音";
		} else startVoiceCapture("device");
	});
	voiceStart.addEventListener("click", () => startVoiceCapture("test"));
	document.querySelector("#voice-finish").addEventListener("click", finishVoiceTest);
	document.querySelector("#voice-report-close").addEventListener("click", () => voiceReportDialog.close());
	voiceReportDialog.addEventListener("click", (event) => {
		if (event.target === voiceReportDialog) voiceReportDialog.close();
	});
	document.querySelector("#back-button").addEventListener("click", () => {
		location.hash = "";
	});
	document.querySelector("#professional-link").addEventListener("click", () => {
		location.hash = "professional";
	});
	document.querySelector("#professional-back").addEventListener("click", () => {
		location.hash = "hearing";
	});
	document.querySelector("#start-test").addEventListener("click", startProfessionalTest);
	document.querySelector("#restart-test").addEventListener("click", startProfessionalTest);
	reportClose.addEventListener("click", () => reportDialog.close());
	reportDialog.addEventListener("click", (event) => {
		if (event.target === reportDialog) reportDialog.close();
	});
	nextTrialButton.addEventListener("click", () => {
		if (trialFeedback) {
			trialFeedback = null;
			if (professionalTest.phase === "done") {
				renderProfessionalState();
				return;
			}
		}
		startProfessionalTrial();
	});
	testAnswers.addEventListener("click", (event) => {
		const button = event.target.closest("button[data-answer]");
		if (!button || !trialActive || !professionalTest) return;
		trialActive = false;
		silenceProfessionalTone();
		const phase = professionalTest.phase;
		const judgedFrequency = professionalTest.frequency;
		const result = answerProfessionalTrial(professionalTest, trialSignal, button.dataset.answer);
		trialFeedback = _objectSpread2(_objectSpread2({}, result), {}, {
			phase,
			frequency: judgedFrequency,
			signal: trialSignal,
			answer: button.dataset.answer
		});
		if (result.done) {
			saveProfessionalResult();
			destroyProfessionalToneEngine();
		}
		renderProfessionalState();
	});
	menuItems.forEach((item) => {
		if ([
			"hearing-link",
			"voice-link",
			"psychology-link",
			"vision-link",
			"certificate-link"
		].includes(item.id)) return;
		item.addEventListener("click", () => {
			showToast(`${item.dataset.title}功能正在准备中`);
		});
	});
	slider.addEventListener("input", () => {
		setFrequency(Number(slider.value));
	});
	setupStepButton(decreaseButton, -1);
	setupStepButton(increaseButton, 1);
	window.addEventListener("pointerup", (event) => {
		if (event.pointerId === heldPointerId) stopStepping();
	});
	window.addEventListener("pointercancel", (event) => {
		if (event.pointerId === heldPointerId) stopStepping();
	});
	window.addEventListener("blur", stopStepping);
	window.addEventListener("resize", () => window.requestAnimationFrame(drawVisibleVoiceCharts));
	playButton.addEventListener("click", toggleSound);
	window.addEventListener("hashchange", showCurrentView);
	window.addEventListener("pagehide", () => {
		stopStepping();
		resetProfessionalTest();
		stopVoiceCapture();
	});
	setFrequency(frequency);
	renderRecords();
	renderVoiceRecords();
	showCurrentView();
	document.addEventListener("visibilitychange", () => {
		if (document.hidden) {
			stopStepping();
			stopSound();
			resetProfessionalTest();
			stopVoiceCapture();
		}
	});
	//#endregion
})();
